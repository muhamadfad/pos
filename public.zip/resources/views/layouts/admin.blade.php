<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{ config('app.name', 'Admin Panel') }}</title>

    @vite(['resources/js/app.js', 'resources/css/app.css'])

    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />

    <script src="https://code.iconify.design/3/3.1.1/iconify.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <meta name="turbo-cache-control" content="no-preview">
    <script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>

    <style>
        [x-cloak] {
            display: none !important;
        }
    </style>
    <style>
        /* ===== Custom Sidebar Scrollbar ===== */

        .sidebar-scroll::-webkit-scrollbar {
            width: 6px;
        }

        .sidebar-scroll::-webkit-scrollbar-track {
            background: transparent;
        }

        .sidebar-scroll::-webkit-scrollbar-thumb {
            background-color: #334155;
            /* slate-700 */
            border-radius: 20px;
        }

        .sidebar-scroll::-webkit-scrollbar-thumb:hover {
            background-color: #475569;
            /* slate-600 */
        }

        /* Firefox */
        .sidebar-scroll {
            scrollbar-width: thin;
            scrollbar-color: #334155 transparent;
        }
    </style>

</head>


<body class="font-sans antialiased bg-slate-100 text-slate-800">

    <div x-data="{
        sidebarOpen: false,
        sidebarCollapsed: window.innerWidth < 768
    }" class="h-screen overflow-hidden">

        <!-- Overlay -->
        <div x-show="sidebarOpen" x-cloak @click="sidebarOpen = false" class="fixed inset-0 bg-black/40 z-30 md:hidden">
        </div>

        <!-- SIDEBAR -->
        <aside x-cloak :class="[
            sidebarOpen ? 'translate-x-0' : '-translate-x-full',
            sidebarCollapsed ? 'w-20' : 'w-64'
        ]" class="fixed inset-y-0 left-0 z-40
               bg-slate-900 text-slate-400
               border-r border-slate-800
               shadow-xl
               transform transition-all duration-300
               flex flex-col md:translate-x-0">

            <!-- Logo -->
            <div class="px-5 py-5 border-b border-slate-800 space-y-1">

                <div class="flex items-center gap-3">
                    <span class="iconify text-2xl text-indigo-500" data-icon="mdi:storefront"></span>
                    <span x-show="!sidebarCollapsed" class="font-semibold text-white text-base tracking-tight">
                        AnoaDev
                    </span>
                </div>

                <div x-show="!sidebarCollapsed" class="pl-9">
                                        <p class="text-[11px] text-slate-500">Kendari</p>
                </div>

            </div>


            <!-- NAV -->
            <nav class="flex-1 py-4 px-3 space-y-1 overflow-y-auto sidebar-scroll text-sm">

                <!-- Dashboard -->
                <!-- Dashboard -->
                <a href="{{ route('admin.dashboard') }}" class="flex items-center gap-3 px-4 py-2.5 rounded-xl transition-all duration-200
               {{ request()->routeIs('admin.dashboard')
                    ? 'bg-slate-800 text-white'
                    : 'hover:bg-slate-800 hover:text-white' }}">
                    <span class="iconify text-xl text-slate-400" data-icon="mdi:view-dashboard-outline"></span>
                    <span x-show="!sidebarCollapsed">Dashboard</span>
                </a>

                <!-- POS Kasir -->
                <a href="{{ route('pos.shift.index') }}" data-turbo="false" class="flex items-center gap-3 px-4 py-2.5 rounded-xl transition-all duration-200
               {{ request()->routeIs('pos.*')
                    ? 'bg-slate-800 text-white'
                    : 'hover:bg-slate-800 hover:text-white' }}">
                    <span class="iconify text-xl text-slate-400" data-icon="mdi:cash-register"></span>
                    <span x-show="!sidebarCollapsed">POS Kasir</span>
                </a>

                <!-- Produk -->
                <a href="{{ route('admin.products.index') }}" class="flex items-center gap-3 px-4 py-2.5 rounded-xl transition-all duration-200
               {{ request()->routeIs('admin.products.*')
                    ? 'bg-slate-800 text-white'
                    : 'hover:bg-slate-800 hover:text-white' }}">
                    <span class="iconify text-xl text-slate-400" data-icon="mdi:package-variant-closed"></span>
                    <span x-show="!sidebarCollapsed">Produk</span>
                </a>

                <!-- Kategori -->
                <a href="{{ route('admin.categories.index') }}" class="flex items-center gap-3 px-4 py-2.5 rounded-xl transition-all duration-200
               {{ request()->routeIs('admin.categories.*')
                    ? 'bg-slate-800 text-white'
                    : 'hover:bg-slate-800 hover:text-white' }}">
                    <span class="iconify text-xl text-slate-400" data-icon="mdi:shape-outline"></span>
                    <span x-show="!sidebarCollapsed">Kategori</span>
                </a>

                <!-- Supplier -->
                <a href="{{ route('admin.suppliers.index') }}" class="flex items-center gap-3 px-4 py-2.5 rounded-xl transition-all duration-200
               {{ request()->routeIs('admin.suppliers.*')
                    ? 'bg-slate-800 text-white'
                    : 'hover:bg-slate-800 hover:text-white' }}">
                    <span class="iconify text-xl text-slate-400" data-icon="mdi:truck-outline"></span>
                    <span x-show="!sidebarCollapsed">Supplier</span>
                </a>

                <!-- Customer -->
                <a href="{{ route('admin.customers.index') }}" class="flex items-center gap-3 px-4 py-2.5 rounded-xl transition-all duration-200
               {{ request()->routeIs('admin.customers.*')
                    ? 'bg-slate-800 text-white'
                    : 'hover:bg-slate-800 hover:text-white' }}">
                    <span class="iconify text-xl text-slate-400" data-icon="mdi:account-group-outline"></span>
                    <span x-show="!sidebarCollapsed">Customer</span>
                </a>

                <!-- TRANSAKSI DROPDOWN -->
                <div
                    x-data="{ open: {{ request()->routeIs('admin.purchases.*', 'admin.orders.*', 'admin.purchase-payments.*', 'admin.order-payments.*') ? 'true' : 'false' }} }">

                    <button @click="open = !open" class="w-full flex items-center justify-between gap-3 px-4 py-2.5 rounded-xl
                           hover:bg-slate-800 hover:text-white transition">

                        <div class="flex items-center gap-3">
                            <span class="iconify text-xl text-slate-400" data-icon="mdi:swap-horizontal"></span>
                            <span x-show="!sidebarCollapsed">Transaksi</span>
                        </div>

                        <span x-show="!sidebarCollapsed" class="iconify text-base transition-transform"
                            :class="{'rotate-180': open}" data-icon="mdi:chevron-down"></span>
                    </button>

                    <div x-show="open" x-collapse class="mt-1 space-y-1 pl-6">

                        <a href="{{ route('admin.purchases.index') }}" class="block px-4 py-2 rounded-xl transition
                       {{ request()->routeIs('admin.purchases.*')
                            ? 'bg-slate-800 text-white'
                            : 'text-slate-400 hover:text-white hover:bg-slate-800' }}">
                            Pembelian
                        </a>

                        <a href="{{ route('admin.orders.index') }}" class="block px-4 py-2 rounded-xl transition
                       {{ request()->routeIs('admin.orders.*')
                            ? 'bg-slate-800 text-white'
                            : 'text-slate-400 hover:text-white hover:bg-slate-800' }}">
                            Penjualan
                        </a>

                        <a href="{{ route('admin.purchase-payments.index') }}" class="block px-4 py-2 rounded-xl transition
                       {{ request()->routeIs('admin.purchase-payments.*')
                            ? 'bg-slate-800 text-white'
                            : 'text-slate-400 hover:text-white hover:bg-slate-800' }}">
                            Hutang
                        </a>

                        <a href="{{ route('admin.order-payments.index') }}" class="block px-4 py-2 rounded-xl transition
                       {{ request()->routeIs('admin.order-payments.*')
                            ? 'bg-slate-800 text-white'
                            : 'text-slate-400 hover:text-white hover:bg-slate-800' }}">
                            Piutang
                        </a>

                    </div>
                </div>

                <!-- FINANCE DROPDOWN -->
                <div x-data="{ openFinance: {{ request()->routeIs('admin.finance.*') ? 'true' : 'false' }} }">

                    <button @click="openFinance = !openFinance" class="w-full flex items-center justify-between gap-3 px-4 py-2.5 rounded-xl
                           hover:bg-slate-800 hover:text-white transition">

                        <div class="flex items-center gap-3">
                            <span class="iconify text-xl text-slate-400" data-icon="mdi:finance"></span>
                            <span x-show="!sidebarCollapsed">Finance</span>
                        </div>

                        <span x-show="!sidebarCollapsed" class="iconify text-base transition-transform"
                            :class="{'rotate-180': openFinance}" data-icon="mdi:chevron-down"></span>
                    </button>

                    <div x-show="openFinance" x-collapse class="mt-1 space-y-1 pl-6">

                        <a href="{{ route('admin.finance.index') }}"
                            class="block px-4 py-2 rounded-xl hover:bg-slate-800 hover:text-white transition">
                            Laporan
                        </a>
                        <a href="{{ route('admin.finance.daily') }}"
                            class="block px-4 py-2 rounded-xl hover:bg-slate-800 hover:text-white transition">
                            Harian
                        </a>
                        <a href="{{ route('admin.finance.weekly') }}"
                            class="block px-4 py-2 rounded-xl hover:bg-slate-800 hover:text-white transition">
                            Mingguan
                        </a>
                        <a href="{{ route('admin.finance.monthly') }}"
                            class="block px-4 py-2 rounded-xl hover:bg-slate-800 hover:text-white transition">
                            Bulanan
                        </a>

                    </div>
                </div>

                <!-- Pengeluaran -->
                <a href="{{ route('admin.expenses.index') }}" class="flex items-center gap-3 px-4 py-2.5 rounded-xl transition-all duration-200
                            {{ request()->routeIs('admin.expenses.*')
                                    ? 'bg-slate-800 text-white'
                                    : 'hover:bg-slate-800 hover:text-white' }}">
                    <span class="iconify text-xl text-slate-400" data-icon="mdi:cash-minus"></span>
                    <span x-show="!sidebarCollapsed">Pengeluaran</span>
                </a>

                <!-- ========== KASPRO MENU ========== -->
                <div x-data="{ openKaspro: {{ request()->routeIs('kaspro.*') ? 'true' : 'false' }} }">

                    <button @click="openKaspro = !openKaspro" class="w-full flex items-center justify-between gap-3 px-4 py-2.5 rounded-xl
                        hover:bg-slate-800 hover:text-white transition">

                        <div class="flex items-center gap-3">
                            <span class="iconify text-xl text-slate-400" data-icon="mdi:chart-line"></span>
                            <span x-show="!sidebarCollapsed">KasPro</span>
                        </div>

                        <span x-show="!sidebarCollapsed" class="iconify text-base transition-transform"
                            :class="{'rotate-180': openKaspro}" data-icon="mdi:chevron-down"></span>
                    </button>

                    <div x-show="openKaspro" x-collapse class="mt-1 space-y-1 pl-6">

                        <a href="{{ route('kaspro.dashboard') }}"
                            class="block px-4 py-2 rounded-xl transition
                        {{ request()->routeIs('kaspro.dashboard')
                                ? 'bg-slate-800 text-white'
                                : 'text-slate-400 hover:text-white hover:bg-slate-800' }}">
                            Dashboard KasPro
                        </a>

                        <a href="{{ route('kaspro.prediction') }}"
                            class="block px-4 py-2 rounded-xl transition
                        {{ request()->routeIs('kaspro.prediction')
                                ? 'bg-slate-800 text-white'
                                : 'text-slate-400 hover:text-white hover:bg-slate-800' }}">
                            Prediksi Arus Kas
                        </a>

                        <a href="{{ route('kaspro.alerts') }}"
                            class="block px-4 py-2 rounded-xl transition
                        {{ request()->routeIs('kaspro.alerts')
                                ? 'bg-slate-800 text-white'
                                : 'text-slate-400 hover:text-white hover:bg-slate-800' }}">
                            Peringatan
                            @php
                                $unreadAlerts = \App\Models\KasproAlert::where('user_id', Auth::id())
                                    ->where('is_read', false)
                                    ->count();
                            @endphp
                            @if($unreadAlerts > 0)
                                <span class="ml-2 px-2 py-0.5 text-xs bg-red-500 text-white rounded-full">{{ $unreadAlerts }}</span>
                            @endif
                        </a>

                        <a href="{{ route('kaspro.margin-analysis') }}"
                            class="block px-4 py-2 rounded-xl transition
                        {{ request()->routeIs('kaspro.margin-analysis')
                                ? 'bg-slate-800 text-white'
                                : 'text-slate-400 hover:text-white hover:bg-slate-800' }}">
                            Analisis Margin
                        </a>

                    </div>
                </div>
                

                <!-- User -->
                <a href="{{ route('admin.users.index') }}"
                    class="flex items-center gap-3 px-4 py-2.5 rounded-xl transition hover:bg-slate-800 hover:text-white">
                    <span class="iconify text-xl text-slate-400" data-icon="mdi:account-multiple-outline"></span>
                    <span x-show="!sidebarCollapsed">User</span>
                </a>

                <!-- Profil -->
                <a href="{{ route('profile.edit') }}"
                    class="flex items-center gap-3 px-4 py-2.5 rounded-xl transition hover:bg-slate-800 hover:text-white">
                    <span class="iconify text-xl text-slate-400" data-icon="mdi:account-circle-outline"></span>
                    <span x-show="!sidebarCollapsed">Profil</span>
                </a>

            </nav>

            <div class="border-t border-slate-800 p-4 space-y-4">



                <!-- Credit -->
                <div x-show="!sidebarCollapsed" class="text-[11px] text-slate-500 leading-relaxed">
                    <p>Built by</p>
                    <p class="text-slate-400 font-medium">
                        Anoadev
                    </p>
                    <p class="text-slate-600">
                        CV. Anoa Nusantara Solusi
                    </p>
                </div>

            </div>


        </aside>

        <!-- MAIN -->
        <div class="h-screen overflow-y-auto transition-all duration-300"
            :class="sidebarCollapsed ? 'md:ml-20' : 'md:ml-64'">

            <!-- TOPBAR -->
            <header class="bg-white/80 backdrop-blur-md border-b border-slate-200 sticky top-0 z-20">
                <div class="flex items-center justify-between px-8 py-4">

                    <!-- LEFT -->
                    <div class="flex items-center gap-4">

                        <button @click="sidebarOpen = true" class="md:hidden p-2 rounded hover:bg-slate-100">
                            <span class="iconify text-2xl" data-icon="mdi:menu"></span>
                        </button>

                        <button @click="sidebarCollapsed = !sidebarCollapsed"
                            class="hidden md:inline-flex p-2 rounded hover:bg-slate-100">
                            <span class="iconify text-xl" data-icon="mdi:menu-open"></span>
                        </button>

                        <h2 class="text-xl font-semibold tracking-tight">
                            @yield('title', 'Dashboard')
                        </h2>

                    </div>


                    <!-- CENTER SEARCH -->
                    <div class="hidden md:flex flex-1 justify-center px-8">
                        <div class="relative w-full max-w-md">
                            <span class="iconify absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"
                                data-icon="mdi:magnify"></span>
                            <input type="text" placeholder="Cari produk, transaksi..." class="w-full pl-10 pr-4 py-2.5 rounded-xl
                              bg-slate-100 border border-slate-200
                              focus:outline-none focus:ring-2 focus:ring-indigo-500
                              text-sm transition">
                        </div>
                    </div>


                    <!-- RIGHT -->
                    <div class="flex items-center gap-6">

                        <!-- Location -->
                        <div class="hidden lg:flex items-center gap-2 text-sm text-slate-600">
                            <span class="iconify text-lg text-indigo-500" data-icon="mdi:map-marker"></span>
                            <span>Kolaka</span>
                        </div>

                        <!-- Notification -->
                        <div class="relative">
                            <button class="p-2 rounded-xl hover:bg-slate-100 transition relative">
                                <span class="iconify text-xl text-slate-600" data-icon="mdi:bell-outline"></span>

                                <!-- Badge untuk total alert KasPro -->
                                @php
                                    $totalUnreadAlerts = \App\Models\KasproAlert::where('user_id', Auth::id())
                                        ->where('is_read', false)
                                        ->count();
                                @endphp
                                @if($totalUnreadAlerts > 0)
                                    <span class="absolute -top-1 -right-1 bg-red-500 text-white text-[10px]
                                    w-5 h-5 flex items-center justify-center rounded-full">
                                        {{ $totalUnreadAlerts > 9 ? '9+' : $totalUnreadAlerts }}
                                    </span>
                                @endif
                            </button>
                        </div>


                        <!-- PROFILE DROPDOWN -->
                        <div x-data="{ openProfile:false }" class="relative">

                            <button @click="openProfile = !openProfile"
                                class="flex items-center gap-3 p-1.5 rounded-xl hover:bg-slate-100 transition">

                                <img src="https://ui-avatars.com/api/?name={{ urlencode(Auth::user()->name) }}"
                                    class="w-9 h-9 rounded-xl" alt="User Avatar">

                                <div class="hidden sm:block text-left">
                                    <p class="text-sm font-medium leading-tight">
                                        {{ Auth::user()->name }}
                                    </p>
                                    <p class="text-xs text-slate-500">
                                        Administrator
                                    </p>
                                </div>

                                <span class="iconify text-base text-slate-500" data-icon="mdi:chevron-down"></span>
                            </button>


                            <!-- DROPDOWN -->
                            <div x-show="openProfile" @click.away="openProfile=false" x-transition class="absolute right-0 mt-3 w-56 bg-white border border-slate-200
                            rounded-2xl shadow-xl py-2 text-sm z-50">

                                <a href="{{ route('profile.edit') }}"
                                    class="flex items-center gap-3 px-4 py-2.5 hover:bg-slate-100 transition">
                                    <span class="iconify text-lg text-slate-500"
                                        data-icon="mdi:account-circle-outline"></span>
                                    Profil
                                </a>

                                <div class="border-t my-2"></div>

                                <form method="POST" action="{{ route('logout') }}" data-turbo="false">
                                    @csrf
                                    <button type="submit" class="w-full flex items-center gap-3 px-4 py-2.5
                                       text-red-500 hover:bg-red-50 transition">
                                        <span class="iconify text-lg" data-icon="mdi:logout-variant"></span>
                                        Logout
                                    </button>
                                </form>

                            </div>

                        </div>

                    </div>

                </div>
            </header>


            <main class="p-8 bg-slate-100 min-h-full">
                @yield('content')
            </main>

        </div>

    </div>

    <!-- ===== GLOBAL DELETE CONFIRM MODAL ===== -->
    <div id="deleteModal" class="fixed inset-0 z-[999] flex items-center justify-center p-4"
        style="display:none!important">

        <!-- Backdrop -->
        <div class="absolute inset-0 bg-slate-900/50 backdrop-blur-sm" onclick="closeDeleteModal()"></div>

        <!-- Card -->
        <div class="relative bg-white rounded-2xl shadow-2xl w-full max-w-md p-6 space-y-5">

            <!-- Icon -->
            <div class="flex items-center gap-4">
                <div class="flex-shrink-0 w-12 h-12 rounded-full bg-red-100 flex items-center justify-center">
                    <span class="iconify text-2xl text-red-600" data-icon="mdi:trash-can-outline"></span>
                </div>
                <div>
                    <h3 class="text-base font-bold text-slate-800">Konfirmasi Hapus</h3>
                    <p class="text-sm text-slate-500 mt-0.5">Tindakan ini tidak dapat dibatalkan.</p>
                </div>
            </div>

            <!-- Message -->
            <div class="bg-slate-50 rounded-xl px-4 py-3 text-sm text-slate-600 border border-slate-200">
                Apakah Anda yakin ingin menghapus
                <span id="deleteModalName" class="font-semibold text-slate-800"></span>?
            </div>

            <!-- Actions -->
            <div class="flex justify-end gap-3">
                <button onclick="closeDeleteModal()"
                    class="px-4 py-2 text-sm font-semibold text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-xl transition">
                    Batal
                </button>
                <form id="deleteModalForm" method="POST">
                    @csrf
                    @method('DELETE')
                    <button type="submit"
                        class="inline-flex items-center gap-2 px-4 py-2 text-sm font-semibold text-white bg-red-600 hover:bg-red-700 rounded-xl transition shadow-sm shadow-red-100">
                        <span class="iconify" data-icon="mdi:trash-can-outline"></span>
                        Ya, Hapus
                    </button>
                </form>
            </div>

        </div>
    </div>

    @stack('scripts')

    <script>
        function confirmDelete(url, name) {
        document.getElementById('deleteModalName').textContent = name ?? 'item ini';
        document.getElementById('deleteModalForm').action = url;
        document.getElementById('deleteModal').style.removeProperty('display');
    }
    function confirmAction(formId, name) {
        document.getElementById('deleteModalName').textContent = name ?? 'tindakan ini';
        // Override submit to submit the target form instead
        const btn = document.querySelector('#deleteModalForm button[type=submit]');
        const originalClick = btn.onclick;
        document.getElementById('deleteModalForm').onsubmit = function(e) {
            e.preventDefault();
            document.getElementById(formId).submit();
            closeDeleteModal();
        };
        document.getElementById('deleteModal').style.removeProperty('display');
    }
    function closeDeleteModal() {
        document.getElementById('deleteModal').style.display = 'none';
        // Reset form submit
        document.getElementById('deleteModalForm').onsubmit = null;
    }
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') closeDeleteModal();
    });
    </script>

  <script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>
</body>

</html>
