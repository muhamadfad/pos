@extends('layouts.admin')

@section('title', 'Prediksi Arus Kas')

@section('content')
<div class="space-y-6">
    <!-- Header -->
    <div>
        <h1 class="text-2xl font-bold text-gray-900">Prediksi Arus Kas</h1>
        <p class="text-gray-600">Proyeksi 6 bulan ke depan berdasarkan data historis</p>
    </div>

    <!-- Pass data ke JavaScript via window object -->
    <script>
        window.historicalData = {
            months: @json($historicalData['months'] ?? []),
            income: @json($historicalData['income'] ?? []),
            expense: @json($historicalData['expense'] ?? [])
        };
    </script>

    <!-- Growth Rate Card -->
    @if(isset($prediction['growth_rate']))
    <div class="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-xl p-6 border border-blue-100">
        <div class="flex items-center gap-4">
            <div class="p-3 bg-blue-100 rounded-full">
                <span class="text-2xl">📈</span>
            </div>
            <div>
                <h3 class="text-lg font-semibold text-gray-900">Tren Pertumbuhan</h3>
                <p class="text-gray-600">Dibandingkan periode yang sama tahun lalu</p>
                <p class="text-2xl font-bold {{ ($prediction['growth_rate'] ?? 1) >= 1 ? 'text-green-600' : 'text-red-600' }}">
                    {{ number_format((($prediction['growth_rate'] ?? 1) - 1) * 100, 1) }}%
                    @if(($prediction['growth_rate'] ?? 1) >= 1)
                        <span class="text-sm font-normal text-green-600">(meningkat)</span>
                    @else
                        <span class="text-sm font-normal text-red-600">(menurun)</span>
                    @endif
                </p>
            </div>
        </div>
    </div>
    @endif

    <!-- Predictions Grid -->
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <div class="px-6 py-4 border-b border-gray-100">
            <h2 class="text-lg font-semibold text-gray-900">Prediksi 6 Bulan ke Depan</h2>
            <p class="text-sm text-gray-500 mt-1">Berdasarkan pola musiman tahun lalu + pertumbuhan terkini</p>
        </div>
        <div class="p-6">
            @if(!empty($prediction['predictions']))
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
                    @foreach($prediction['predictions'] as $pred)
                        <div class="border border-gray-200 rounded-xl overflow-hidden hover:shadow-md transition">
                            <div class="px-4 py-3 {{ ($pred['predicted_net'] ?? 0) >= 0 ? 'bg-green-50 border-b border-green-100' : 'bg-red-50 border-b border-red-100' }}">
                                <h3 class="font-semibold text-gray-900">{{ $pred['month_name'] }}</h3>
                                @if(isset($pred['seasonal_factor']))
                                    <p class="text-xs text-gray-500 mt-0.5">
                                        Faktor musiman: <strong class="text-blue-600">{{ $pred['seasonal_factor'] }}x</strong>
                                        @if(($pred['seasonal_factor'] ?? 0) > 1.2)
                                            <span class="ml-1 text-green-600">(puncak)</span>
                                        @elseif(($pred['seasonal_factor'] ?? 0) < 0.8)
                                            <span class="ml-1 text-orange-600">(rendah)</span>
                                        @endif
                                    </p>
                                @endif
                            </div>
                            <div class="p-4 space-y-3">
                                <div class="flex justify-between items-center">
                                    <span class="text-sm text-gray-600">Pemasukan</span>
                                    <span class="text-base font-semibold text-green-600">Rp {{ number_format($pred['predicted_income'] ?? 0, 0, ',', '.') }}</span>
                                </div>
                                <div class="flex justify-between items-center">
                                    <span class="text-sm text-gray-600">Pengeluaran</span>
                                    <span class="text-base font-semibold text-red-600">Rp {{ number_format($pred['predicted_expense'] ?? 0, 0, ',', '.') }}</span>
                                </div>
                                <div class="pt-2 mt-2 border-t border-gray-100">
                                    <div class="flex justify-between items-center">
                                        <span class="text-sm font-medium text-gray-700">Net Cash Flow</span>
                                        <span class="text-lg font-bold {{ ($pred['predicted_net'] ?? 0) >= 0 ? 'text-green-600' : 'text-red-600' }}">
                                            Rp {{ number_format($pred['predicted_net'] ?? 0, 0, ',', '.') }}
                                        </span>
                                    </div>
                                    @if(isset($pred['last_year_income']) && ($pred['last_year_income'] ?? 0) > 0)
                                        <p class="text-xs text-gray-400 mt-2">
                                            Tahun lalu: Rp {{ number_format($pred['last_year_income'] ?? 0, 0, ',', '.') }}
                                        </p>
                                    @endif
                                </div>
                            </div>
                        </div>
                    @endforeach
                </div>
            @else
                <div class="text-center py-12 text-gray-500">
                    <span class="text-5xl mb-4 block">📊</span>
                    <p>Data belum cukup untuk prediksi.</p>
                    <p class="text-sm mt-1">Minimal 12 bulan data historis diperlukan untuk prediksi yang akurat.</p>
                </div>
            @endif
        </div>
    </div>

    <!-- Recommendations -->
    @if(!empty($prediction['recommendations']))
    <div class="bg-yellow-50 rounded-xl p-6 border border-yellow-100">
        <div class="flex items-start gap-3">
            <span class="text-2xl">💡</span>
            <div class="flex-1">
                <h3 class="font-semibold text-yellow-800">Rekomendasi KasPro</h3>
                <div class="mt-2 space-y-2">
                    @foreach($prediction['recommendations'] as $rec)
                        <p class="text-sm text-yellow-700">{{ $rec }}</p>
                    @endforeach
                </div>
            </div>
        </div>
    </div>
    @endif

    <!-- Peak Months Insight -->
    @if(isset($prediction['peak_months']) && count($prediction['peak_months']) > 0)
    <div class="bg-blue-50 rounded-xl p-4 border border-blue-100">
        <p class="text-sm text-blue-700">
            📊 <strong>Insight Musiman:</strong> Berdasarkan data tahun lalu, bulan puncak penjualan terjadi pada: 
            <strong>{{ implode(', ', $prediction['peak_months']) }}</strong>
        </p>
    </div>
    @endif

    <!-- Historical Chart for Reference -->
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
        <h2 class="text-lg font-semibold text-gray-900 mb-4">Data Historis 12 Bulan</h2>
        <canvas id="historicalChart" height="300" style="max-height: 350px;"></canvas>
        @if(empty($historicalData['months']) || count($historicalData['months']) == 0)
            <div class="text-center py-8 text-gray-500">
                <p>Belum ada data historis untuk ditampilkan.</p>
                <p class="text-sm">Data akan muncul setelah ada transaksi penjualan dan pembelian.</p>
            </div>
        @endif
    </div>
</div>

@push('scripts')
<script>
    // Chart sudah diinisialisasi di app.js via event listener
    console.log('Prediction page loaded, historicalData:', window.historicalData);
</script>
@endpush
@endsection