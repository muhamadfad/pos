@extends('layouts.admin')

@section('title', 'KasPro Dashboard')

@section('content')
<div class="space-y-6">
    <!-- Header -->
    <div>
        <h1 class="text-2xl font-bold text-gray-900">KasPro - Arus Kas Cerdas</h1>
        <p class="text-gray-600">Monitor dan prediksi kesehatan keuangan bisnis Anda</p>
    </div>

    <!-- Stats Cards Row -->
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <!-- Survival Card -->
        <div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
            <div class="p-6">
                <div class="flex justify-between items-start">
                    <div>
                        <p class="text-sm text-gray-500 mb-1">Saldo Kas Saat Ini</p>
                        <p class="text-3xl font-bold text-gray-900">{{ $survival['current_cash_formatted'] }}</p>
                    </div>
                    <div class="text-right">
                        <p class="text-sm text-gray-500 mb-1">Bisa Bertahan</p>
                        <p class="text-3xl font-bold text-{{ $survival['status_color'] }}-600">{{ $survival['days_to_survive'] }} <span class="text-base font-normal text-gray-500">hari</span></p>
                        <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-{{ $survival['status_color'] }}-100 text-{{ $survival['status_color'] }}-800">
                            {{ $survival['status'] }}
                        </span>
                    </div>
                </div>
                <div class="mt-4 pt-4 border-t border-gray-100">
                    <p class="text-sm text-gray-600">
                        Rata-rata pengeluaran harian: <strong class="text-gray-900">{{ $survival['avg_daily_expense_formatted'] }}</strong>
                    </p>
                </div>
            </div>
        </div>

        <!-- Cash Flow Summary Card -->
        <div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
            <div class="p-6">
                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <p class="text-sm text-gray-500 mb-1">Pemasukan {{ ucfirst($cashFlow['period']) }}</p>
                        <p class="text-2xl font-bold text-green-600">Rp {{ number_format($cashFlow['total_income'], 0, ',', '.') }}</p>
                    </div>
                    <div>
                        <p class="text-sm text-gray-500 mb-1">Pengeluaran {{ ucfirst($cashFlow['period']) }}</p>
                        <p class="text-2xl font-bold text-red-600">Rp {{ number_format($cashFlow['total_expense'], 0, ',', '.') }}</p>
                    </div>
                </div>
                <div class="mt-3">
                    <div class="flex justify-between text-xs text-gray-500 mb-1">
                        <span>Stok: Rp {{ number_format($cashFlow['expense_breakdown']['stok'], 0, ',', '.') }}</span>
                        <span>Operasional: Rp {{ number_format($cashFlow['expense_breakdown']['operasional'], 0, ',', '.') }}</span>
                    </div>
                    <div class="w-full bg-gray-200 rounded-full h-2">
                        @php
                            $totalExpense = $cashFlow['total_expense'];
                            $stokPercent = $totalExpense > 0 ? ($cashFlow['expense_breakdown']['stok'] / $totalExpense) * 100 : 0;
                        @endphp
                        <div class="bg-blue-500 h-2 rounded-full" style="width: {{ $stokPercent }}%"></div>
                    </div>
                </div>
                <div class="mt-4 pt-4 border-t border-gray-100">
                    <div class="flex justify-between items-center">
                        <span class="text-sm text-gray-600">Net Cash Flow:</span>
                        <span class="text-lg font-semibold {{ $cashFlow['net_cash_flow'] >= 0 ? 'text-green-600' : 'text-red-600' }}">
                            Rp {{ number_format($cashFlow['net_cash_flow'], 0, ',', '.') }}
                        </span>
                    </div>
                    <p class="text-xs text-gray-400 mt-1">Periode: {{ $cashFlow['start_date'] }} - {{ $cashFlow['end_date'] }}</p>
                </div>
            </div>
        </div>
    </div>

    <!-- Historical Chart -->
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
        <div class="flex justify-between items-center mb-4">
            <h2 class="text-lg font-semibold text-gray-900">Grafik Arus Kas 12 Bulan Terakhir</h2>
            <div class="flex gap-2">
                <span class="inline-flex items-center gap-1 text-xs">
                    <span class="w-3 h-3 rounded-full bg-green-500"></span>
                    <span class="text-gray-600">Pemasukan</span>
                </span>
                <span class="inline-flex items-center gap-1 text-xs">
                    <span class="w-3 h-3 rounded-full bg-red-500"></span>
                    <span class="text-gray-600">Pengeluaran</span>
                </span>
            </div>
        </div>
        <div id="cashFlowChart" style="height: 350px;"></div>
    </div>

    <!-- Predictions Section -->
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <div class="px-6 py-4 border-b border-gray-100">
            <h2 class="text-lg font-semibold text-gray-900">Prediksi 3 Bulan ke Depan</h2>
            @if(isset($prediction['growth_rate']))
                <p class="text-sm text-gray-500 mt-1">Growth rate: {{ number_format(($prediction['growth_rate'] - 1) * 100, 1) }}% dibanding tahun lalu</p>
            @endif
        </div>
        <div class="p-6">
            @if(!empty($prediction['predictions']))
                <div class="grid grid-cols-1 md:grid-cols-3 gap-5">
                    @foreach($prediction['predictions'] as $pred)
                        <div class="border border-gray-200 rounded-xl overflow-hidden hover:shadow-md transition">
                            <div class="px-4 py-3 {{ $pred['predicted_net'] >= 0 ? 'bg-green-50 border-b border-green-100' : 'bg-red-50 border-b border-red-100' }}">
                                <h3 class="font-semibold text-gray-900">{{ $pred['month_name'] }}</h3>
                                @if(isset($pred['seasonal_factor']))
                                    <p class="text-xs text-gray-500 mt-0.5">Faktor musiman: {{ $pred['seasonal_factor'] }}x</p>
                                @endif
                            </div>
                            <div class="p-4 space-y-2">
                                <div class="flex justify-between items-center">
                                    <span class="text-sm text-gray-600">Pemasukan</span>
                                    <span class="text-base font-semibold text-green-600">Rp {{ number_format($pred['predicted_income'], 0, ',', '.') }}</span>
                                </div>
                                <div class="flex justify-between items-center">
                                    <span class="text-sm text-gray-600">Pengeluaran</span>
                                    <span class="text-base font-semibold text-red-600">Rp {{ number_format($pred['predicted_expense'], 0, ',', '.') }}</span>
                                </div>
                                <div class="pt-2 mt-2 border-t border-gray-100">
                                    <div class="flex justify-between items-center">
                                        <span class="text-sm font-medium text-gray-700">Net</span>
                                        <span class="text-lg font-bold {{ $pred['predicted_net'] >= 0 ? 'text-green-600' : 'text-red-600' }}">
                                            Rp {{ number_format($pred['predicted_net'], 0, ',', '.') }}
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    @endforeach
                </div>
            @else
                <div class="text-center py-8 text-gray-500">
                    <p>Data belum cukup untuk prediksi. Minimal 12 bulan data diperlukan.</p>
                </div>
            @endif

            @if(!empty($prediction['recommendations']))
                <div class="mt-6 p-4 bg-yellow-50 rounded-xl border border-yellow-100">
                    <div class="flex items-start gap-3">
                        <span class="text-xl">💡</span>
                        <div>
                            <h3 class="font-medium text-yellow-800">Rekomendasi KasPro</h3>
                            <div class="mt-2 space-y-1">
                                @foreach($prediction['recommendations'] as $rec)
                                    <p class="text-sm text-yellow-700">{{ $rec }}</p>
                                @endforeach
                            </div>
                        </div>
                    </div>
                </div>
            @endif

            @if(isset($prediction['peak_months']) && count($prediction['peak_months']) > 0)
                <div class="mt-4 p-3 bg-blue-50 rounded-lg">
                    <p class="text-sm text-blue-700">
                        📊 Bulan puncak penjualan berdasarkan data tahun lalu: <strong>{{ implode(', ', $prediction['peak_months']) }}</strong>
                    </p>
                </div>
            @endif
        </div>
    </div>

    <!-- Recent Alerts -->
    @if($recentAlerts->count() > 0)
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <div class="px-6 py-4 border-b border-gray-100">
            <h2 class="text-lg font-semibold text-gray-900">Peringatan Terbaru</h2>
        </div>
        <div class="divide-y divide-gray-100">
            @foreach($recentAlerts as $alert)
            <div class="p-4 hover:bg-gray-50 transition">
                <div class="flex justify-between items-start">
                    <div class="flex-1">
                        <div class="flex items-center gap-2 mb-1">
                            @if($alert->severity == 'emergency')
                                <span class="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">Darurat</span>
                            @elseif($alert->severity == 'critical')
                                <span class="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-orange-100 text-orange-800">Kritis</span>
                            @elseif($alert->severity == 'warning')
                                <span class="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">Peringatan</span>
                            @else
                                <span class="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">Info</span>
                            @endif
                            <span class="font-medium text-gray-900">{{ $alert->title }}</span>
                        </div>
                        <p class="text-sm text-gray-600">{{ $alert->message }}</p>
                        <p class="text-xs text-gray-400 mt-1">{{ $alert->created_at->diffForHumans() }}</p>
                    </div>
                    <a href="{{ route('kaspro.alerts') }}" class="text-sm text-blue-600 hover:text-blue-800 font-medium">Lihat →</a>
                </div>
            </div>
            @endforeach
        </div>
    </div>
    @endif
</div>

@push('scripts')
<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Data dari server
        const months = @json($historicalData['months'] ?? []);
        const incomeData = @json($historicalData['income'] ?? []);
        const expenseData = @json($historicalData['expense'] ?? []);
        
        // Pastikan ApexCharts tersedia
        if (typeof ApexCharts !== 'undefined' && months.length > 0) {
            const options = {
                series: [
                    {
                        name: 'Pemasukan',
                        type: 'line',
                        data: incomeData,
                        color: '#10b981'
                    },
                    {
                        name: 'Pengeluaran',
                        type: 'line',
                        data: expenseData,
                        color: '#ef4444'
                    }
                ],
                chart: {
                    height: 350,
                    type: 'line',
                    toolbar: {
                        show: true,
                        tools: {
                            download: true,
                            selection: false,
                            zoom: true,
                            zoomin: true,
                            zoomout: true,
                            pan: true,
                            reset: true
                        }
                    },
                    zoom: {
                        enabled: true,
                        type: 'x',
                        autoScaleYaxis: true
                    }
                },
                stroke: {
                    width: [3, 3],
                    curve: 'smooth',
                    dashArray: [0, 0]
                },
                markers: {
                    size: 4,
                    hover: {
                        size: 6
                    }
                },
                fill: {
                    opacity: [0.1, 0.1],
                    type: 'solid'
                },
                xaxis: {
                    categories: months,
                    title: {
                        text: 'Bulan',
                        style: {
                            fontSize: '12px'
                        }
                    },
                    labels: {
                        rotate: -45,
                        style: {
                            fontSize: '11px'
                        }
                    }
                },
                yaxis: {
                    title: {
                        text: 'Jumlah (Rp)',
                        style: {
                            fontSize: '12px'
                        }
                    },
                    labels: {
                        formatter: function(value) {
                            if (value >= 1000000000) {
                                return 'Rp ' + (value / 1000000000).toFixed(1) + ' M';
                            } else if (value >= 1000000) {
                                return 'Rp ' + (value / 1000000).toFixed(1) + ' Jt';
                            } else if (value >= 1000) {
                                return 'Rp ' + (value / 1000).toFixed(0) + ' rb';
                            }
                            return 'Rp ' + value;
                        }
                    }
                },
                tooltip: {
                    y: {
                        formatter: function(value) {
                            return 'Rp ' + new Intl.NumberFormat('id-ID').format(value);
                        }
                    },
                    shared: true,
                    intersect: false
                },
                legend: {
                    position: 'top',
                    horizontalAlign: 'right',
                    offsetY: -10
                },
                grid: {
                    borderColor: '#e5e7eb',
                    strokeDashArray: 5,
                    xaxis: {
                        lines: {
                            show: true
                        }
                    }
                }
            };
            
            const chart = new ApexCharts(document.querySelector("#cashFlowChart"), options);
            chart.render();
        } else {
            // Fallback jika ApexCharts tidak tersedia
            console.log('ApexCharts not loaded or no data');
            document.querySelector('#cashFlowChart').innerHTML = '<div class="flex items-center justify-center h-full text-gray-500">Loading chart...</div>';
        }
    });
</script>
@endpush
@endsection