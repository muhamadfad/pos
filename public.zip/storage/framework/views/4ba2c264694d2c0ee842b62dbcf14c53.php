<div>
    <!-- The only way to do great work is to love what you do. - Steve Jobs -->
</div><?php /**PATH C:\Users\Muhamad Fadlan\Desktop\depobangun\resources\views/components/kpi-card.blade.php ENDPATH**/ ?>