

<?php $__env->startSection('title', 'Analisis Margin Produk'); ?>

<?php $__env->startSection('content'); ?>
<div class="space-y-6">
    <!-- Header -->
    <div>
        <h1 class="text-2xl font-bold text-gray-900">Analisis Margin Produk</h1>
        <p class="text-gray-600">10 produk dengan penjualan tertinggi</p>
    </div>

    <!-- Top Products Table -->
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <div class="overflow-x-auto">
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Produk</th>
                        <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Terjual</th>
                        <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Total Revenue</th>
                        <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Estimasi Margin</th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                    <?php $__empty_1 = true; $__currentLoopData = $topProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="hover:bg-gray-50">
                        <td class="px-6 py-4 text-sm font-medium text-gray-900">
                            <?php echo e($item->product_name); ?>

                        </td>
                        <td class="px-6 py-4 text-sm text-right text-gray-700">
                            <?php echo e(number_format($item->total_sold, 0, ',', '.')); ?> pcs
                        </td>
                        <td class="px-6 py-4 text-sm text-right text-green-600 font-medium">
                            Rp <?php echo e(number_format($item->total_revenue, 0, ',', '.')); ?>

                        </td>
                        <td class="px-6 py-4 text-sm text-right">
                            <?php
                                $avgCost = $item->purchase_price ?? 0;
                                $estimatedMargin = $item->total_revenue - ($avgCost * $item->total_sold);
                                $marginPercent = $item->total_revenue > 0 ? ($estimatedMargin / $item->total_revenue) * 100 : 0;
                            ?>
                            <span class="<?php echo e($marginPercent >= 30 ? 'text-green-600' : ($marginPercent >= 15 ? 'text-yellow-600' : 'text-red-600')); ?>">
                                Rp <?php echo e(number_format($estimatedMargin, 0, ',', '.')); ?>

                                <span class="text-xs">(<?php echo e(number_format($marginPercent, 1)); ?>%)</span>
                            </span>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="4" class="px-6 py-12 text-center text-gray-500">
                            <span class="text-4xl mb-2 block">📦</span>
                            Belum ada data penjualan
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Insight -->
    <div class="bg-blue-50 rounded-xl p-4 border border-blue-100">
        <p class="text-sm text-blue-700">
            💡 <strong>Tips:</strong> Fokuskan stok pada produk dengan margin tertinggi untuk memaksimalkan keuntungan.
        </p>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Muhamad Fadlan\Desktop\buat2 sj\kasproxkasir\resources\views/kaspro/margin-analysis.blade.php ENDPATH**/ ?>