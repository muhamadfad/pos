<?php $__env->startSection('title', 'Rincian Saldo Bersih'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-7xl mx-auto space-y-8">

    
    <div class="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
            <div class="flex items-center gap-3 mb-1">
                <a href="<?php echo e(route('admin.finance.index')); ?>"
                    class="text-slate-400 hover:text-slate-600 transition-colors">
                    <span class="iconify text-xl" data-icon="mdi:arrow-left"></span>
                </a>
                <h1 class="text-2xl font-black text-slate-800 tracking-tight">Rincian Saldo Bersih</h1>
            </div>
            <p class="text-slate-500 text-sm ml-9">
                Saldo Bersih = Pendapatan Penjualan − Bayar Supplier − Pengeluaran Operasional
            </p>
        </div>
        <div class="flex items-center gap-2 p-1 bg-slate-100 rounded-2xl">
            <a href="<?php echo e(route('admin.finance.index')); ?>"
                class="px-4 py-2 rounded-xl text-xs font-bold transition-all text-slate-500 hover:text-slate-700">Ringkasan</a>
            <a href="<?php echo e(route('admin.finance.daily')); ?>"
                class="px-4 py-2 rounded-xl text-xs font-bold transition-all text-slate-500 hover:text-slate-700">Harian</a>
            <a href="<?php echo e(route('admin.finance.weekly')); ?>"
                class="px-4 py-2 rounded-xl text-xs font-bold transition-all text-slate-500 hover:text-slate-700">Mingguan</a>
            <a href="<?php echo e(route('admin.finance.monthly')); ?>"
                class="px-4 py-2 rounded-xl text-xs font-bold transition-all text-slate-500 hover:text-slate-700">Bulanan</a>
        </div>
    </div>

    
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        
        <div class="bg-white rounded-[2rem] border border-slate-200 shadow-sm p-7">
            <div class="flex items-center gap-3 mb-4">
                <div class="w-10 h-10 rounded-2xl bg-emerald-50 flex items-center justify-center">
                    <span class="iconify text-emerald-600 text-xl" data-icon="mdi:trending-up"></span>
                </div>
                <p class="text-[11px] font-black text-slate-400 uppercase tracking-widest">Pendapatan</p>
            </div>
            <p class="text-2xl font-black text-slate-900">Rp <?php echo e(number_format($totalIncome, 0, ',', '.')); ?></p>
            <p class="text-xs text-slate-400 mt-1">Total dari penjualan</p>
        </div>

        
        <div class="bg-white rounded-[2rem] border border-slate-200 shadow-sm p-7">
            <div class="flex items-center gap-3 mb-4">
                <div class="w-10 h-10 rounded-2xl bg-orange-50 flex items-center justify-center">
                    <span class="iconify text-orange-500 text-xl" data-icon="mdi:truck-outline"></span>
                </div>
                <p class="text-[11px] font-black text-slate-400 uppercase tracking-widest">Bayar Supplier</p>
            </div>
            <p class="text-2xl font-black text-slate-900">Rp <?php echo e(number_format($totalSupplierPaid, 0, ',', '.')); ?></p>
            <p class="text-xs text-slate-400 mt-1">Total sudah dibayarkan</p>
        </div>

        
        <div class="bg-white rounded-[2rem] border border-slate-200 shadow-sm p-7">
            <div class="flex items-center gap-3 mb-4">
                <div class="w-10 h-10 rounded-2xl bg-rose-50 flex items-center justify-center">
                    <span class="iconify text-rose-500 text-xl" data-icon="mdi:cash-remove"></span>
                </div>
                <p class="text-[11px] font-black text-slate-400 uppercase tracking-widest">Operasional</p>
            </div>
            <p class="text-2xl font-black text-slate-900">Rp <?php echo e(number_format($totalOperasional, 0, ',', '.')); ?></p>
            <p class="text-xs text-slate-400 mt-1">Biaya listrik, gaji, dll</p>
        </div>

        
        <?php $isPositive = $netCashflow >= 0; ?>
        <div class="<?php echo e($isPositive ? 'bg-indigo-600' : 'bg-rose-600'); ?> rounded-[2rem] shadow-xl p-7">
            <div class="flex items-center gap-3 mb-4">
                <div class="w-10 h-10 rounded-2xl bg-white/20 flex items-center justify-center">
                    <span class="iconify text-white text-xl"
                        data-icon="<?php echo e($isPositive ? 'mdi:piggy-bank' : 'mdi:alert-circle-outline'); ?>"></span>
                </div>
                <p class="text-[11px] font-black text-white/60 uppercase tracking-widest">Saldo Bersih</p>
            </div>
            <p class="text-2xl font-black text-white">Rp <?php echo e(number_format(abs($netCashflow), 0, ',', '.')); ?></p>
            <p class="text-xs text-white/60 mt-1"><?php echo e($isPositive ? 'Surplus' : 'Defisit'); ?></p>
        </div>
        
            <div class="bg-yellow-500 rounded-[2rem] shadow-xl p-7">
                <div class="flex items-center gap-3 mb-4">
                    <div class="w-10 h-10 rounded-2xl bg-white/20 flex items-center justify-center">
                        <span class="iconify text-white text-xl" data-icon="mdi:cash-multiple"></span>
                    </div>
                    <p class="text-[11px] font-black text-white/60 uppercase tracking-widest">Keuntungan Bersih</p>
                </div>
                <p class="text-2xl font-black text-white">Rp <?php echo e(number_format($totalProfit, 0, ',', '.')); ?></p>
                <p class="text-xs text-white/60 mt-1">Pendapatan − HPP</p>
            </div>
    </div>

    
    <div class="bg-slate-50 border border-slate-200 rounded-[2rem] p-6">
        <p class="text-xs font-black text-slate-400 uppercase tracking-widest mb-4">Formula Perhitungan</p>
        <div class="flex flex-wrap items-center gap-3 text-sm font-bold">
            <span class="px-4 py-2 bg-emerald-50 text-emerald-700 border border-emerald-200 rounded-xl">
                Rp <?php echo e(number_format($totalIncome, 0, ',', '.')); ?> <span
                    class="font-normal text-emerald-500">(Pendapatan)</span>
            </span>
            <span class="text-slate-400 text-lg">−</span>
            <span class="px-4 py-2 bg-orange-50 text-orange-700 border border-orange-200 rounded-xl">
                Rp <?php echo e(number_format($totalSupplierPaid, 0, ',', '.')); ?> <span
                    class="font-normal text-orange-500">(Supplier)</span>
            </span>
            <span class="text-slate-400 text-lg">−</span>
            <span class="px-4 py-2 bg-rose-50 text-rose-700 border border-rose-200 rounded-xl">
                Rp <?php echo e(number_format($totalOperasional, 0, ',', '.')); ?> <span
                    class="font-normal text-rose-500">(Operasional)</span>
            </span>
            <span class="text-slate-400 text-lg">=</span>
            <span
                class="px-4 py-2 <?php echo e($isPositive ? 'bg-indigo-600 text-white' : 'bg-rose-600 text-white'); ?> rounded-xl">
                Rp <?php echo e(number_format($netCashflow, 0, ',', '.')); ?>

            </span>
        </div>
    </div>

    
    <div class="bg-white rounded-[2rem] border border-slate-200 shadow-sm overflow-hidden">
        <div class="px-8 py-5 border-b border-slate-100">
            <h3 class="font-black text-slate-800 text-sm uppercase tracking-widest">Tren 12 Bulan Terakhir</h3>
        </div>
        <div class="overflow-x-auto p-6">
            <table class="w-full text-sm min-w-[600px]">
                <thead>
                    <tr
                        class="text-[10px] font-black text-slate-400 uppercase tracking-widest border-b border-slate-100">
                        <th class="pb-3 text-left px-2">Bulan</th>
                        <th class="pb-3 text-right px-2">Pendapatan</th>
                        <th class="pb-3 text-right px-2">Bayar Supplier</th>
                        <th class="pb-3 text-right px-2">Operasional</th>
                        <th class="pb-3 text-right px-2">Saldo Bersih</th>
                        <th class="pb-3 text-left px-2 w-40">Bar</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-50">
                    <?php
                    $maxNet = $months->max(fn($m) => abs($m['net'])) ?: 1;
                    $maxIncome = $months->max(fn($m) => $m['income']) ?: 1;
                    ?>
                    <?php $__currentLoopData = $months; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $month): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $pos = $month['net'] >= 0; ?>
                    <tr class="hover:bg-slate-50 transition-colors">
                        <td class="py-3 px-2 font-bold text-slate-700"><?php echo e($month['label']); ?></td>
                        <td class="py-3 px-2 text-right text-emerald-600 font-semibold">
                            Rp <?php echo e(number_format($month['income'], 0, ',', '.')); ?>

                        </td>
                        <td class="py-3 px-2 text-right text-orange-500 font-semibold">
                            Rp <?php echo e(number_format($month['supplier'], 0, ',', '.')); ?>

                        </td>
                        <td class="py-3 px-2 text-right text-rose-500 font-semibold">
                            Rp <?php echo e(number_format($month['operasional'], 0, ',', '.')); ?>

                        </td>
                        <td class="py-3 px-2 text-right font-black <?php echo e($pos ? 'text-indigo-600' : 'text-rose-600'); ?>">
                            Rp <?php echo e(number_format($month['net'], 0, ',', '.')); ?>

                        </td>
                        <td class="py-3 px-2">
                            <?php $pct = min(100, abs($month['net']) / $maxNet * 100); ?>
                            <div class="w-full bg-slate-100 rounded-full h-2">
                                <div class="h-2 rounded-full <?php echo e($pos ? 'bg-indigo-500' : 'bg-rose-400'); ?>"
                                    style="width: <?php echo e($pct); ?>%"></div>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

    
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">

        
        <div class="bg-white rounded-[2rem] border border-slate-200 shadow-sm overflow-hidden">
            <div class="px-8 py-5 border-b border-slate-100">
                <h3 class="font-black text-slate-800 text-sm uppercase tracking-widest">Pengeluaran per Kategori</h3>
            </div>
            <div class="p-6">
                <?php if($expenseByCategory->isEmpty()): ?>
                <p class="text-sm text-slate-400 text-center py-6 italic">Belum ada data pengeluaran operasional.</p>
                <?php else: ?>
                <?php $totalCat = $expenseByCategory->sum('total') ?: 1; ?>
                <div class="space-y-3">
                    <?php $__currentLoopData = $expenseByCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $pct = $cat->total / $totalCat * 100; ?>
                    <div>
                        <div class="flex justify-between items-center mb-1">
                            <span class="text-sm font-bold text-slate-700 capitalize"><?php echo e($cat->category ?? 'Lainnya'); ?></span>
                            <span class="text-sm font-black text-slate-900">Rp <?php echo e(number_format($cat->total, 0, ',',
                                '.')); ?></span>
                        </div>
                        <div class="w-full bg-slate-100 rounded-full h-2">
                            <div class="h-2 rounded-full bg-rose-400" style="width: <?php echo e($pct); ?>%"></div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php endif; ?>
            </div>
        </div>

        
        <div class="bg-white rounded-[2rem] border border-slate-200 shadow-sm overflow-hidden">
            <div class="px-8 py-5 border-b border-slate-100 flex items-center justify-between">
                <h3 class="font-black text-slate-800 text-sm uppercase tracking-widest">Pembayaran Terbesar ke Supplier
                </h3>
            </div>
            <div class="divide-y divide-slate-50">
                <?php $__empty_1 = true; $__currentLoopData = $topSupplierPurchases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purchase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <a href="<?php echo e(route('admin.purchases.show', $purchase->id)); ?>"
                    class="flex items-center justify-between px-6 py-4 hover:bg-slate-50 transition-colors group">
                    <div class="flex items-center gap-3">
                        <div class="w-9 h-9 rounded-xl bg-orange-50 flex items-center justify-center shrink-0">
                            <span class="iconify text-orange-500" data-icon="mdi:truck-outline"></span>
                        </div>
                        <div>
                            <p class="font-bold text-slate-800 text-sm"><?php echo e($purchase->supplier->name ?? '—'); ?></p>
                            <p class="text-[11px] text-slate-400">
                                <?php echo e(\Carbon\Carbon::parse($purchase->date)->format('d M Y')); ?>

                                &nbsp;•&nbsp;
                                <span
                                    class="font-bold <?php echo e($purchase->payment_status === 'paid' ? 'text-emerald-500' : 'text-orange-500'); ?>">
                                    <?php echo e($purchase->payment_status === 'paid' ? 'Lunas' : ($purchase->payment_status ===
                                    'partial' ? 'Sebagian' : 'Belum Bayar')); ?>

                                </span>
                            </p>
                        </div>
                    </div>
                    <div class="text-right">
                        <p class="font-black text-slate-900 text-sm">Rp <?php echo e(number_format($purchase->total_paid, 0, ',',
                            '.')); ?></p>
                        <p class="text-[10px] text-slate-400">dari Rp <?php echo e(number_format($purchase->total_amount, 0, ',',
                            '.')); ?></p>
                    </div>
                </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="text-sm text-slate-400 text-center py-8 italic">Belum ada data pembelian.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Muhamad Fadlan\Desktop\depobangun\resources\views/admin/finance/cashflow.blade.php ENDPATH**/ ?>