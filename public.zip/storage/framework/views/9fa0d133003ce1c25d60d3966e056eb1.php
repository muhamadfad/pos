<?php $__env->startSection('title', isset($supplier) ? 'Edit Supplier' : 'Tambah Supplier'); ?>

<?php $__env->startSection('content'); ?>
<div class="w-full mx-auto space-y-6">

    <!-- Header -->
    <div class="flex items-center gap-4">
        <a href="<?php echo e(route('admin.suppliers.index')); ?>"
            class="inline-flex items-center justify-center w-9 h-9 rounded-xl bg-white border border-slate-200 text-slate-500 hover:bg-slate-50 hover:text-indigo-600 transition shadow-sm">
            <span class="iconify" data-icon="mdi:arrow-left"></span>
        </a>
        <div>
            <h1 class="text-2xl font-bold text-slate-800">
                <?php echo e(isset($supplier) ? 'Edit Supplier' : 'Tambah Supplier'); ?>

            </h1>
            <p class="text-sm text-slate-500 mt-0.5">
                <?php echo e(isset($supplier) ? 'Perbarui data supplier' : 'Daftarkan supplier baru'); ?>

            </p>
        </div>
    </div>

    <!-- Card Form -->
    <div class="bg-white rounded-2xl border border-slate-200 shadow-sm p-6">

        <?php if($errors->any()): ?>
        <div
            class="flex items-start gap-3 bg-red-50 border border-red-200 text-red-700 rounded-xl px-4 py-3 mb-5 text-sm">
            <span class="iconify mt-0.5 shrink-0 text-red-500" data-icon="mdi:alert-circle-outline"></span>
            <span><?php echo e(implode(', ', $errors->all())); ?></span>
        </div>
        <?php endif; ?>

        <form
            action="<?php echo e(isset($supplier) ? route('admin.suppliers.update', $supplier) : route('admin.suppliers.store')); ?>"
            method="POST" class="space-y-5">
            <?php echo csrf_field(); ?>
            <?php if(isset($supplier)): ?>
            <?php echo method_field('PUT'); ?>
            <?php endif; ?>

            <!-- Nama -->
            <div>
                <label class="block text-sm font-semibold text-slate-700 mb-1.5">
                    Nama Supplier <span class="text-red-500 ml-0.5">*</span>
                </label>
                <div class="relative">
                    <div class="absolute inset-y-0 left-0 flex items-center pl-3.5 pointer-events-none text-slate-400">
                        <span class="iconify" data-icon="mdi:truck-outline"></span>
                    </div>
                    <input type="text" name="name" value="<?php echo e(old('name', $supplier->name ?? '')); ?>"
                        placeholder="Nama supplier" autofocus class="w-full pl-10 pr-4 py-2.5 text-sm border rounded-xl transition
                               <?php echo e($errors->has('name') ? 'border-red-400 bg-red-50 focus:ring-red-300' : 'border-slate-300 focus:ring-indigo-200 focus:border-indigo-400'); ?>

                               focus:outline-none focus:ring-2">
                </div>
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="mt-1.5 text-xs text-red-600 flex items-center gap-1">
                    <span class="iconify" data-icon="mdi:alert-circle-outline"></span> <?php echo e($message); ?>

                </p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- Alamat -->
            <div>
                <label class="block text-sm font-semibold text-slate-700 mb-1.5">Alamat</label>
                <div class="relative">
                    <div class="absolute inset-y-0 left-0 flex items-center pl-3.5 pointer-events-none text-slate-400">
                        <span class="iconify" data-icon="mdi:map-marker-outline"></span>
                    </div>
                    <input type="text" name="address" value="<?php echo e(old('address', $supplier->address ?? '')); ?>"
                        placeholder="Alamat lengkap"
                        class="w-full pl-10 pr-4 py-2.5 text-sm border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-200 focus:border-indigo-400 transition">
                </div>
                <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="mt-1.5 text-xs text-red-600 flex items-center gap-1">
                    <span class="iconify" data-icon="mdi:alert-circle-outline"></span> <?php echo e($message); ?>

                </p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- No HP -->
            <div>
                <label class="block text-sm font-semibold text-slate-700 mb-1.5">No HP</label>
                <div class="relative">
                    <div class="absolute inset-y-0 left-0 flex items-center pl-3.5 pointer-events-none text-slate-400">
                        <span class="iconify" data-icon="mdi:phone-outline"></span>
                    </div>
                    <input type="text" name="phone" value="<?php echo e(old('phone', $supplier->phone ?? '')); ?>"
                        placeholder="08xxxxxxxxxx"
                        class="w-full pl-10 pr-4 py-2.5 text-sm border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-200 focus:border-indigo-400 transition">
                </div>
                <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="mt-1.5 text-xs text-red-600 flex items-center gap-1">
                    <span class="iconify" data-icon="mdi:alert-circle-outline"></span> <?php echo e($message); ?>

                </p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- Jenis -->
            <div>
                <label class="block text-sm font-semibold text-slate-700 mb-1.5">Jenis Supplier</label>
                <div class="relative">
                    <div class="absolute inset-y-0 left-0 flex items-center pl-3.5 pointer-events-none text-slate-400">
                        <span class="iconify" data-icon="mdi:tag-outline"></span>
                    </div>
                    <input type="text" name="type" value="<?php echo e(old('type', $supplier->type ?? '')); ?>"
                        placeholder="Depo Bangunan / Toko Material / dll"
                        class="w-full pl-10 pr-4 py-2.5 text-sm border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-200 focus:border-indigo-400 transition">
                </div>
                <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="mt-1.5 text-xs text-red-600 flex items-center gap-1">
                    <span class="iconify" data-icon="mdi:alert-circle-outline"></span> <?php echo e($message); ?>

                </p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- Actions -->
            <div class="flex items-center justify-between pt-2">
                <a href="<?php echo e(route('admin.suppliers.index')); ?>"
                    class="inline-flex items-center gap-2 px-4 py-2.5 text-sm font-medium text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-xl transition">
                    <span class="iconify" data-icon="mdi:arrow-left"></span>
                    Kembali
                </a>
                <button type="submit"
                    class="inline-flex items-center gap-2 px-6 py-2.5 text-sm font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl transition shadow-md shadow-indigo-100">
                    <span class="iconify" data-icon="mdi:content-save-outline"></span>
                    <?php echo e(isset($supplier) ? 'Update' : 'Simpan'); ?>

                </button>
            </div>
        </form>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Muhamad Fadlan\Desktop\depobangun\resources\views/admin/suppliers/form.blade.php ENDPATH**/ ?>