<div class="overflow-x-auto">
    <table class="w-full text-left border-collapse min-w-[800px]">
        <thead>
            <tr class="bg-slate-50/50 border-b border-slate-100">
                <th class="px-6 py-5 text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">#</th>
                <th class="px-6 py-5 text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">User & Kredensial
                </th>
                <th class="px-6 py-5 text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">Role Otoritas
                </th>
                <th class="px-6 py-5 text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">Status Akses</th>
                <th class="px-6 py-5 text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] text-center">
                    Tindakan</th>
            </tr>
        </thead>

        <tbody class="divide-y divide-slate-100 font-medium">
            <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr class="hover:bg-slate-50 transition-all duration-200 group">
                <td class="px-6 py-5 text-slate-400 text-xs">
                    <?php echo e($users->firstItem() + $loop->index); ?>

                </td>

                <td class="px-6 py-5">
                    <div class="flex items-center gap-3">
                        <div
                            class="w-10 h-10 rounded-xl bg-slate-100 flex items-center justify-center text-slate-500 font-bold transition-all group-hover:bg-indigo-100 group-hover:text-indigo-600">
                            <?php echo e(strtoupper(substr($user->name, 0, 1))); ?>

                        </div>
                        <div>
                            <p
                                class="text-sm font-black text-slate-800 tracking-tight leading-none mb-1 group-hover:text-indigo-600 transition-colors">
                                <?php echo e($user->name); ?>

                            </p>
                            <p class="text-xs text-slate-400 font-medium tracking-tight">
                                <?php echo e($user->email); ?>

                            </p>
                        </div>
                    </div>
                </td>

                <td class="px-6 py-5">
                    <div class="flex items-center gap-2">
                        <?php if($user->role === 'admin'): ?>
                        <span
                            class="p-1 px-3 rounded-lg bg-indigo-50 text-indigo-600 text-[10px] font-black uppercase tracking-widest border border-indigo-100">
                            Administrator
                        </span>
                        <?php else: ?>
                        <span
                            class="p-1 px-3 rounded-lg bg-slate-100 text-slate-500 text-[10px] font-black uppercase tracking-widest border border-slate-200">
                            Staff / Kasir
                        </span>
                        <?php endif; ?>
                    </div>
                </td>

                <td class="px-6 py-5">
                    <div class="flex items-center gap-2">
                        <?php if($user->is_active): ?>
                        <span class="flex items-center gap-1.5 text-emerald-600 text-xs font-bold">
                            <span class="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                            Aktif
                        </span>
                        <?php else: ?>
                        <span class="flex items-center gap-1.5 text-slate-400 text-xs font-bold">
                            <span class="w-2 h-2 rounded-full bg-slate-300"></span>
                            Suspend
                        </span>
                        <?php endif; ?>
                    </div>
                </td>

                <td class="px-6 py-5">
                    <div class="flex justify-center gap-2">
                        <a href="<?php echo e(route('admin.users.edit', $user)); ?>"
                            class="p-2 bg-white border border-slate-200 rounded-xl text-slate-600 hover:text-indigo-600 hover:border-indigo-100 hover:bg-indigo-50 transition-all shadow-sm">
                            <span class="iconify text-lg" data-icon="mdi:pencil-outline"></span>
                        </a>

                        <button type="button"
                            @click="confirmDelete('<?php echo e(route('admin.users.destroy', $user)); ?>', '<?php echo e(addslashes($user->name)); ?>')"
                            <?php echo e(auth()->id() == $user->id ? 'disabled' : ''); ?>

                            class="p-2 bg-white border border-slate-200 rounded-xl text-slate-600 hover:text-rose-600
                            hover:border-rose-100 hover:bg-rose-50 transition-all shadow-sm disabled:opacity-30
                            disabled:cursor-not-allowed">
                            <span class="iconify text-lg" data-icon="mdi:trash-can-outline"></span>
                        </button>
                    </div>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="5" class="py-24 text-center">
                    <div class="flex flex-col items-center justify-center space-y-3 opacity-30">
                        <span class="iconify text-6xl" data-icon="mdi:account-search-outline"></span>
                        <p class="font-black uppercase tracking-widest text-xs">Data user belum tersedia</p>
                    </div>
                </td>
            </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<div class="p-8 bg-slate-50/50 border-t border-slate-100">
    <?php echo e($users->links()); ?>

</div>
<?php /**PATH C:\Users\Muhamad Fadlan\Desktop\buat2 sj\kasproxkasir\resources\views/admin/users/partials/table.blade.php ENDPATH**/ ?>