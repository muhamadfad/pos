<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>

<div class="space-y-2">

    <!-- HEADER -->
    <div class="flex flex-col md:flex-row md:justify-between md:items-center gap-4">
        <div>
            <h1 class="text-2xl font-semibold text-slate-800">
                Selamat Datang, <?php echo e(Auth::user()->name ?? 'Admin'); ?> 👋
            </h1>
            <p class="text-slate-500 mt-1">
                Ringkasan performa dan aktivitas sistem hari ini
            </p>
        </div>

        <div class="text-sm text-slate-500">
            <?php echo e(now()->format('d F Y')); ?>

        </div>
    </div>

    <!-- KPI + FINANCE COMPACT -->
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-3 gap-2">

    <!-- Total Barang -->
    <div class="group bg-white p-5 rounded-2xl shadow-sm hover:shadow-xl transition-all duration-300 hover:-translate-y-1">
        <div class="flex items-center justify-between">
            <div>
                <p class="text-xs text-slate-400 uppercase tracking-wide">Total Barang</p>
                <h2 class="text-xl font-semibold mt-1"><?php echo e($totalProducts); ?></h2>
            </div>
            <div class="w-10 h-10 flex items-center justify-center rounded-xl bg-blue-50 group-hover:bg-blue-100 transition">
                <span class="iconify text-xl text-blue-600" data-icon="mdi:package-variant-closed"></span>
            </div>
        </div>
    </div>

    <!-- Stok Menipis -->
    <div class="group bg-white p-5 rounded-2xl shadow-sm hover:shadow-xl transition-all duration-300 hover:-translate-y-1">
        <div class="flex items-center justify-between">
            <div>
                <p class="text-xs text-slate-400 uppercase tracking-wide">Stok Menipis</p>
                <h2 class="text-xl font-semibold mt-1 text-amber-500"><?php echo e($lowStock); ?></h2>
            </div>
            <div class="w-10 h-10 flex items-center justify-center rounded-xl bg-amber-50 group-hover:bg-amber-100 transition">
                <span class="iconify text-xl text-amber-600" data-icon="mdi:alert-circle-outline"></span>
            </div>
        </div>
    </div>

    <!-- Stok Habis -->
    <div class="group bg-white p-5 rounded-2xl shadow-sm hover:shadow-xl transition-all duration-300 hover:-translate-y-1">
        <div class="flex items-center justify-between">
            <div>
                <p class="text-xs text-slate-400 uppercase tracking-wide">Stok Habis</p>
                <h2 class="text-xl font-semibold mt-1 text-red-500"><?php echo e($outOfStock ?? 0); ?></h2>
            </div>
            <div class="w-10 h-10 flex items-center justify-center rounded-xl bg-red-50 group-hover:bg-red-100 transition">
                <span class="iconify text-xl text-red-600" data-icon="mdi:close-circle-outline"></span>
            </div>
        </div>
    </div>

    <!-- Total User -->
    <div class="group bg-white p-5 rounded-2xl shadow-sm hover:shadow-xl transition-all duration-300 hover:-translate-y-1">
        <div class="flex items-center justify-between">
            <div>
                <p class="text-xs text-slate-400 uppercase tracking-wide">Total User</p>
                <h2 class="text-xl font-semibold mt-1"><?php echo e($totalUsers); ?></h2>
            </div>
            <div class="w-10 h-10 flex items-center justify-center rounded-xl bg-green-50 group-hover:bg-green-100 transition">
                <span class="iconify text-xl text-green-600" data-icon="mdi:account-group-outline"></span>
            </div>
        </div>
    </div>

    <!-- Total Piutang -->
    <div class="group bg-white p-5 rounded-2xl shadow-sm hover:shadow-xl transition-all duration-300 hover:-translate-y-1">
        <div class="flex items-center justify-between">
            <div>
                <p class="text-xs text-slate-400 uppercase tracking-wide">Total Piutang</p>
                <h2 class="text-xl font-semibold mt-1 text-emerald-600">Rp <?php echo e(number_format($totalPiutang,0,',','.')); ?></h2>
            </div>
            <div class="w-10 h-10 flex items-center justify-center rounded-xl bg-emerald-50 group-hover:bg-emerald-100 transition">
                <span class="iconify text-xl text-emerald-600" data-icon="mdi:cash-plus"></span>
            </div>
        </div>
    </div>

    <!-- Total Hutang -->
    <div class="group bg-white p-5 rounded-2xl shadow-sm hover:shadow-xl transition-all duration-300 hover:-translate-y-1">
        <div class="flex items-center justify-between">
            <div>
                <p class="text-xs text-slate-400 uppercase tracking-wide">Total Hutang</p>
                <h2 class="text-xl font-semibold mt-1 text-rose-600">Rp <?php echo e(number_format($totalHutang,0,',','.')); ?></h2>
            </div>
            <div class="w-10 h-10 flex items-center justify-center rounded-xl bg-rose-50 group-hover:bg-rose-100 transition">
                <span class="iconify text-xl text-rose-600" data-icon="mdi:cash-minus"></span>
            </div>
        </div>
    </div>

</div>

    <!-- CHART SECTION -->
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-2 items-stretch">

        <!-- AREA CHART -->
        <div class="bg-white rounded-2xl shadow-sm overflow-hidden flex flex-col">
            <div class="p-4 border-b">
                <h3 class="text-lg font-semibold text-slate-700">
                    Ringkasan Keuangan
                </h3>
                <p class="text-sm text-slate-400 mt-1">
                    Pendapatan & Pengeluaran
                </p>
            </div>

            <div class="p-4 flex-1">
                <div id="revenueChart" class="w-full h-[320px]"></div>
            </div>
        </div>

        <!-- DONUT CHART -->
        <div class="bg-white rounded-2xl shadow-sm overflow-hidden flex flex-col">
            <div class="p-4 border-b">
                <h3 class="text-lg font-semibold text-slate-700">
                    Distribusi Stok
                </h3>
                <p class="text-sm text-slate-400 mt-1">
                    Komposisi kategori
                </p>
            </div>

            <div class="p-6 ">
                <div id="stockChart"></div>
            </div>
        </div>

    </div>

    <!-- ACTIVITY LOG -->
    <div class="bg-white rounded-2xl shadow-sm">
        <div class="p-6 border-b font-semibold">Activity Log</div>
        <div class="p-6 space-y-4 text-sm text-slate-600">

            <div class="flex justify-between">
                <span>Admin menambahkan produk baru</span>
                <span class="text-slate-400">5 menit lalu</span>
            </div>

            <div class="flex justify-between">
                <span>Transaksi barang keluar</span>
                <span class="text-slate-400">30 menit lalu</span>
            </div>

            <div class="flex justify-between">
                <span>User baru terdaftar</span>
                <span class="text-slate-400">1 jam lalu</span>
            </div>

        </div>
    </div>

</div>

<script>

function initCharts() {

    const revenueEl = document.querySelector("#revenueChart");
    const stockEl   = document.querySelector("#stockChart");

    // kalau elemen belum ada, jangan lanjut
    if (!revenueEl && !stockEl) return;

    // ===== AREA CHART =====
    if (revenueEl && !revenueEl.dataset.loaded) {

        const revenueChart = new ApexCharts(revenueEl, {
            chart: { 
                type: 'area',
                height: 320,
                toolbar: { show: false }
            },
            series: [
                { name: 'Pendapatan', data: <?php echo json_encode($revenues, 15, 512) ?> },
                { name: 'Pengeluaran', data: <?php echo json_encode($expenses, 15, 512) ?> }
            ],
            xaxis: { categories: <?php echo json_encode($months, 15, 512) ?> },
            stroke: { curve: 'smooth', width: 3 },
            colors: ['#6366f1','#ef4444'],
            dataLabels: { enabled: false }
        });

        revenueChart.render();
        revenueEl.dataset.loaded = "true";
    }

    // ===== DONUT CHART =====
    if (stockEl && !stockEl.dataset.loaded && <?php echo json_encode(count($stockSeries), 15, 512) ?> > 0) {

        const stockChart = new ApexCharts(stockEl, {
            chart: { type: 'donut', height: 320 },
            series: <?php echo json_encode(array_map('intval', $stockSeries), 512) ?>,
            labels: <?php echo json_encode($stockNames, 15, 512) ?>,
            legend: { show: false },
            dataLabels: { enabled: false },
            stroke: { width: 0 },
            plotOptions: {
                pie: { donut: { size: '65%' } }
            }
        });

        stockChart.render();
        stockEl.dataset.loaded = "true";
    }
}


// Jalankan tiap 500ms sampai element muncul
const interval = setInterval(() => {
    if (document.querySelector("#revenueChart") || document.querySelector("#stockChart")) {
        initCharts();
        clearInterval(interval);
    }
}, 500);

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Muhamad Fadlan\Desktop\depobangun\resources\views/dashboard.blade.php ENDPATH**/ ?>