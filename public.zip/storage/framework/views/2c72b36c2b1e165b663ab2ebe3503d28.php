

<?php $__env->startSection('title', 'Prediksi Arus Kas'); ?>

<?php $__env->startSection('content'); ?>
<div class="space-y-6">
    <!-- Header -->
    <div>
        <h1 class="text-2xl font-bold text-gray-900">Prediksi Arus Kas</h1>
        <p class="text-gray-600">Proyeksi 6 bulan ke depan berdasarkan data historis</p>
    </div>

    <!-- Pass data ke JavaScript via window object -->
    <script>
        window.historicalData = {
            months: <?php echo json_encode($historicalData['months'] ?? [], 15, 512) ?>,
            income: <?php echo json_encode($historicalData['income'] ?? [], 15, 512) ?>,
            expense: <?php echo json_encode($historicalData['expense'] ?? [], 15, 512) ?>
        };
    </script>

    <!-- Growth Rate Card -->
    <?php if(isset($prediction['growth_rate'])): ?>
    <div class="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-xl p-6 border border-blue-100">
        <div class="flex items-center gap-4">
            <div class="p-3 bg-blue-100 rounded-full">
                <span class="text-2xl">📈</span>
            </div>
            <div>
                <h3 class="text-lg font-semibold text-gray-900">Tren Pertumbuhan</h3>
                <p class="text-gray-600">Dibandingkan periode yang sama tahun lalu</p>
                <p class="text-2xl font-bold <?php echo e(($prediction['growth_rate'] ?? 1) >= 1 ? 'text-green-600' : 'text-red-600'); ?>">
                    <?php echo e(number_format((($prediction['growth_rate'] ?? 1) - 1) * 100, 1)); ?>%
                    <?php if(($prediction['growth_rate'] ?? 1) >= 1): ?>
                        <span class="text-sm font-normal text-green-600">(meningkat)</span>
                    <?php else: ?>
                        <span class="text-sm font-normal text-red-600">(menurun)</span>
                    <?php endif; ?>
                </p>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <!-- Predictions Grid -->
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <div class="px-6 py-4 border-b border-gray-100">
            <h2 class="text-lg font-semibold text-gray-900">Prediksi 6 Bulan ke Depan</h2>
            <p class="text-sm text-gray-500 mt-1">Berdasarkan pola musiman tahun lalu + pertumbuhan terkini</p>
        </div>
        <div class="p-6">
            <?php if(!empty($prediction['predictions'])): ?>
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
                    <?php $__currentLoopData = $prediction['predictions']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pred): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="border border-gray-200 rounded-xl overflow-hidden hover:shadow-md transition">
                            <div class="px-4 py-3 <?php echo e(($pred['predicted_net'] ?? 0) >= 0 ? 'bg-green-50 border-b border-green-100' : 'bg-red-50 border-b border-red-100'); ?>">
                                <h3 class="font-semibold text-gray-900"><?php echo e($pred['month_name']); ?></h3>
                                <?php if(isset($pred['seasonal_factor'])): ?>
                                    <p class="text-xs text-gray-500 mt-0.5">
                                        Faktor musiman: <strong class="text-blue-600"><?php echo e($pred['seasonal_factor']); ?>x</strong>
                                        <?php if(($pred['seasonal_factor'] ?? 0) > 1.2): ?>
                                            <span class="ml-1 text-green-600">(puncak)</span>
                                        <?php elseif(($pred['seasonal_factor'] ?? 0) < 0.8): ?>
                                            <span class="ml-1 text-orange-600">(rendah)</span>
                                        <?php endif; ?>
                                    </p>
                                <?php endif; ?>
                            </div>
                            <div class="p-4 space-y-3">
                                <div class="flex justify-between items-center">
                                    <span class="text-sm text-gray-600">Pemasukan</span>
                                    <span class="text-base font-semibold text-green-600">Rp <?php echo e(number_format($pred['predicted_income'] ?? 0, 0, ',', '.')); ?></span>
                                </div>
                                <div class="flex justify-between items-center">
                                    <span class="text-sm text-gray-600">Pengeluaran</span>
                                    <span class="text-base font-semibold text-red-600">Rp <?php echo e(number_format($pred['predicted_expense'] ?? 0, 0, ',', '.')); ?></span>
                                </div>
                                <div class="pt-2 mt-2 border-t border-gray-100">
                                    <div class="flex justify-between items-center">
                                        <span class="text-sm font-medium text-gray-700">Net Cash Flow</span>
                                        <span class="text-lg font-bold <?php echo e(($pred['predicted_net'] ?? 0) >= 0 ? 'text-green-600' : 'text-red-600'); ?>">
                                            Rp <?php echo e(number_format($pred['predicted_net'] ?? 0, 0, ',', '.')); ?>

                                        </span>
                                    </div>
                                    <?php if(isset($pred['last_year_income']) && ($pred['last_year_income'] ?? 0) > 0): ?>
                                        <p class="text-xs text-gray-400 mt-2">
                                            Tahun lalu: Rp <?php echo e(number_format($pred['last_year_income'] ?? 0, 0, ',', '.')); ?>

                                        </p>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php else: ?>
                <div class="text-center py-12 text-gray-500">
                    <span class="text-5xl mb-4 block">📊</span>
                    <p>Data belum cukup untuk prediksi.</p>
                    <p class="text-sm mt-1">Minimal 12 bulan data historis diperlukan untuk prediksi yang akurat.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Recommendations -->
    <?php if(!empty($prediction['recommendations'])): ?>
    <div class="bg-yellow-50 rounded-xl p-6 border border-yellow-100">
        <div class="flex items-start gap-3">
            <span class="text-2xl">💡</span>
            <div class="flex-1">
                <h3 class="font-semibold text-yellow-800">Rekomendasi KasPro</h3>
                <div class="mt-2 space-y-2">
                    <?php $__currentLoopData = $prediction['recommendations']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p class="text-sm text-yellow-700"><?php echo e($rec); ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <!-- Peak Months Insight -->
    <?php if(isset($prediction['peak_months']) && count($prediction['peak_months']) > 0): ?>
    <div class="bg-blue-50 rounded-xl p-4 border border-blue-100">
        <p class="text-sm text-blue-700">
            📊 <strong>Insight Musiman:</strong> Berdasarkan data tahun lalu, bulan puncak penjualan terjadi pada: 
            <strong><?php echo e(implode(', ', $prediction['peak_months'])); ?></strong>
        </p>
    </div>
    <?php endif; ?>

    <!-- Historical Chart for Reference -->
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
        <h2 class="text-lg font-semibold text-gray-900 mb-4">Data Historis 12 Bulan</h2>
        <canvas id="historicalChart" height="300" style="max-height: 350px;"></canvas>
        <?php if(empty($historicalData['months']) || count($historicalData['months']) == 0): ?>
            <div class="text-center py-8 text-gray-500">
                <p>Belum ada data historis untuk ditampilkan.</p>
                <p class="text-sm">Data akan muncul setelah ada transaksi penjualan dan pembelian.</p>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
    // Chart sudah diinisialisasi di app.js via event listener
    console.log('Prediction page loaded, historicalData:', window.historicalData);
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Muhamad Fadlan\Desktop\buat2 sj\kasproxkasir\resources\views/kaspro/prediction.blade.php ENDPATH**/ ?>