<?php $__env->startSection('title', 'Barang Masuk'); ?>

<?php $__env->startSection('content'); ?>
<div class="bg-white p-6 rounded-xl shadow-sm border">

    <!-- Header -->
    <div class="flex items-center justify-between mb-6">
        <h2 class="text-xl font-semibold text-gray-800">📥 Barang Masuk</h2>
        <a href="<?php echo e(route('admin.transactions.in.selectSupplier')); ?>"
            class="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition">
            + Tambah Transaksi
        </a>
    </div>

    <!-- Table -->
    <div class="overflow-x-auto">
        <table class="min-w-full text-sm text-left border rounded-lg overflow-hidden">
            <thead class="bg-gray-50 text-gray-600 uppercase text-xs">
                <tr>
                    <th class="px-4 py-3">Tanggal</th>
                    <th class="px-4 py-3">Supplier</th>
                    <th class="px-4 py-3">Daftar Barang</th>
                    <th class="px-4 py-3 text-right">Total</th>
                    <th class="px-4 py-3 text-center">Status</th>

                </tr>
            </thead>
            <tbody class="divide-y">
                <?php $__empty_1 = true; $__currentLoopData = $stockEntries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="hover:bg-gray-50 align-top">

                    <!-- Date -->
                    <td class="px-4 py-3 whitespace-nowrap">
                        <?php echo e(\Carbon\Carbon::parse($row->date)->format('d M Y')); ?>

                    </td>

                    <!-- Supplier -->
                    <td class="px-4 py-3 font-medium text-gray-800">
                        <?php echo e($row->supplier->name ?? '-'); ?>

                    </td>

                    <!-- Items -->
                    <td class="px-4 py-3">
                        <?php $__currentLoopData = $row->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="mb-2">
                            <div class="font-medium text-gray-800">
                                <?php echo e($item->product->name ?? '-'); ?>

                            </div>
                            <div class="text-xs text-gray-500">
                                <?php echo e($item->quantity); ?> x
                                Rp <?php echo e(number_format($item->purchase_price ?? 0, 0, ',', '.')); ?>

                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </td>

                    <!-- Total -->
                    <td class="px-4 py-3 text-right font-semibold text-gray-800">
                        Rp <?php echo e(number_format($row->total_amount, 0, ',', '.')); ?>

                    </td>

                    <!-- Status -->
                    <td class="px-4 py-3 text-center">
                        <span class="px-3 py-1 rounded-full text-xs font-semibold
                            <?php echo e($row->payment_status == 'LUNAS'
                                ? 'bg-green-100 text-green-700'
                                : 'bg-yellow-100 text-yellow-700'); ?>">
                            <?php echo e(strtoupper($row->payment_status)); ?>

                        </span>
                    </td>



                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="6" class="px-4 py-6 text-center text-gray-500">
                        Data barang masuk belum tersedia.
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- Pagination -->
    <div class="mt-4">
        <?php echo e($stockEntries->links()); ?>

    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Muhamad Fadlan\Desktop\depobangun\resources\views/admin/transactions/in/index.blade.php ENDPATH**/ ?>