<div class="bg-white rounded-2xl shadow-sm border overflow-x-auto">

    <table class="w-full text-sm">
        <thead class="bg-gray-50 text-gray-600 uppercase text-xs tracking-wider">
            <tr>
                <th class="px-6 py-4 text-left">Tanggal</th>
                <th class="px-6 py-4 text-left">Barang</th>
                <th class="px-6 py-4 text-left">Total</th>
                <th class="px-6 py-4 text-left">Dibayar</th>
                <th class="px-6 py-4 text-left">Status</th>
                <th class="px-6 py-4 text-center">Detail</th>
            </tr>
        </thead>

        <tbody class="divide-y">
            <?php $__empty_1 = true; $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr class="hover:bg-gray-50 transition">

                <td class="px-6 py-4 text-gray-600">
                    <?php echo e(\Carbon\Carbon::parse($row->date)->format('d M Y')); ?>

                </td>

                <td class="px-6 py-4">
                    <div class="flex flex-wrap gap-1">
                        <?php $__currentLoopData = $row->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <span class="px-2 py-1 bg-gray-100 text-gray-700 rounded-md text-xs">
                            <?php echo e($item->product->name ?? '-'); ?> (<?php echo e($item->quantity); ?>)
                        </span>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </td>

                <td class="px-6 py-4 font-semibold text-gray-800">
                    Rp <?php echo e(number_format($row->total_amount, 0, ',', '.')); ?>

                </td>

                <td class="px-6 py-4 text-blue-600 font-medium">
                    Rp <?php echo e(number_format($row->total_paid, 0, ',', '.')); ?>

                </td>

                <td class="px-6 py-4">
                    <span class="px-3 py-1 rounded-full text-xs font-medium
                        <?php echo e($row->payment_status === 'LUNAS'
                            ? 'bg-green-100 text-green-700'
                            : 'bg-yellow-100 text-yellow-700'); ?>">
                        <?php echo e(strtoupper($row->payment_status)); ?>

                    </span>
                </td>

                <td class="px-6 py-4 text-center">
                    <a href="<?php echo e(route('admin.transactions.in.show', $row->id)); ?>"
                        class="text-indigo-600 hover:text-indigo-800 text-sm font-medium">
                        Lihat
                    </a>
                </td>

            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="6" class="text-center py-12 text-gray-400">
                    Belum ada transaksi.
                </td>
            </tr>
            <?php endif; ?>
        </tbody>
    </table>

    <div class="p-6 border-t bg-gray-50">
        <?php echo e($transactions->links()); ?>

    </div>

</div>
<?php /**PATH C:\Users\Muhamad Fadlan\Desktop\depobangun\resources\views/admin/transactions/in/partials/table.blade.php ENDPATH**/ ?>