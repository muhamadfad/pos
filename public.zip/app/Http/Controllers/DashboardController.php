<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Product;
use App\Models\User;
use App\Models\Order;
use App\Models\Expense;
use App\Models\Purchase;
use Carbon\Carbon;
use App\Models\Category;

class DashboardController extends Controller
{
  public function index()
{
    // =======================
    // BASIC KPI
    // =======================

    $totalProducts = Product::count();

    $lowStock = Product::whereColumn('stock', '<=', 'min_stock')
        ->where('stock', '>', 0)
        ->count();

    $outOfStock = Product::where('stock', 0)->count();

    $totalUsers = User::count();


    // =======================
    // PIUTANG & HUTANG (FIX SESUAI DB)
    // =======================

    $totalPiutang = Order::where('payment_status', '!=', 'paid')
        ->sum('remaining_receivable');

    $totalHutang = Purchase::where('payment_status', '!=', 'paid')
        ->sum('remaining_debt');


    // =======================
    // CHART PENDAPATAN
    // =======================

    $revenueRaw = Order::selectRaw('MONTH(date) as month, SUM(total_amount) as total')
        ->whereYear('date', now()->year)
        ->groupBy('month')
        ->pluck('total', 'month');

    $expenseRaw = Expense::selectRaw('MONTH(date) as month, SUM(amount) as total')
        ->whereYear('date', now()->year)
        ->groupBy('month')
        ->pluck('total', 'month');

    $months = [];
    $revenues = [];
    $expenses = [];

    for ($m = 1; $m <= 12; $m++) {
        $months[] = Carbon::create()->month($m)->format('M');
        $revenues[] = $revenueRaw[$m] ?? 0;
        $expenses[] = $expenseRaw[$m] ?? 0;
    }


    // =======================
    // DISTRIBUSI STOK
    // =======================

   

    $stockData = Product::selectRaw('categories.name as category, SUM(products.stock) as total')
    ->join('categories', 'products.category_id', '=', 'categories.id')
    ->groupBy('categories.name')
    ->get();

$stockNames = $stockData->pluck('category')->toArray();
$stockSeries = $stockData->pluck('total')
    ->map(fn($v) => (int)$v)
    ->toArray();

    return view('dashboard', compact(
        'totalProducts',
        'lowStock',
        'outOfStock',
        'totalUsers',
        'totalPiutang',
        'totalHutang',
        'months',
        'revenues',
        'expenses',
        'stockNames',
        'stockSeries'
    ));
}
}
