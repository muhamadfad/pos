<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Order;
use App\Models\OrderItem;
use App\Models\Purchase;
use App\Models\PurchaseItem;
use App\Models\Expense;
use App\Models\Product;
use App\Models\Supplier;
use App\Models\Customer;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;

class KasproSampleDataSeeder extends Seeder
{
    public function run()
    {
        $this->command->info('🌱 Seeding Kaspro sample data for 12 months...');
        
        // Ambil data yang sudah ada
        $products = Product::all();
        $suppliers = Supplier::all();
        $customers = Customer::all();
        
        // Ambil kategori expense yang sudah ada
        $existingExpenseCategories = Expense::select('category')
            ->whereNotNull('category')
            ->distinct()
            ->pluck('category')
            ->toArray();
        
        if (empty($existingExpenseCategories)) {
            $existingExpenseCategories = [
                'Listrik', 'Air', 'Internet', 'Gaji', 'Transport', 
                'Maintenance', 'ATK', 'Kebersihan', 'Marketing', 'Sewa'
            ];
            $this->command->warn('⚠️ No expense categories found, using default categories.');
        }
        
        if ($products->isEmpty()) {
            $this->command->error('❌ No products found! Please seed products first.');
            return;
        }
        
        if ($suppliers->isEmpty()) {
            $this->command->error('❌ No suppliers found! Please seed suppliers first.');
            return;
        }
        
        if ($customers->isEmpty()) {
            $this->command->error('❌ No customers found! Please seed customers first.');
            return;
        }
        
        $this->command->info('');
        $this->command->info('📊 Products: ' . $products->count());
        $this->command->info('📊 Suppliers: ' . $suppliers->count());
        $this->command->info('📊 Customers: ' . $customers->count());
        $this->command->info('');
        
        // ========== TAMBAHKAN STOK AWAL UNTUK SEMUA PRODUK ==========
        $this->command->info('📦 Setting initial stock for all products...');
        foreach ($products as $product) {
            // Stok awal = min_stock * 5 (agar cukup untuk penjualan awal)
            $initialStock = max($product->min_stock * 5, 50);
            $product->update(['stock' => $initialStock]);
        }
        $this->command->info('✅ Initial stock set.');
        $this->command->info('');
        
        $startDate = Carbon::create(2025, 3, 1);
        $endDate = Carbon::create(2026, 3, 31);
        $currentDate = $startDate->copy();
        
        $orderCount = 0;
        $purchaseCount = 0;
        $expenseCount = 0;
        
        // Track penjualan per produk untuk simulasi
        $productSales = [];
        
        $this->command->info('📅 Generating data from ' . $startDate->format('F Y') . ' to ' . $endDate->format('F Y'));
        $this->command->info('');
        
        while ($currentDate <= $endDate) {
            $year = $currentDate->year;
            $month = $currentDate->month;
            $daysInMonth = $currentDate->daysInMonth;
            $monthName = $currentDate->translatedFormat('F');
            
            $this->command->info('   🔄 Processing ' . $monthName . ' ' . $year . '...');
            
            // ========== 1. ORDERS (Penjualan) ==========
            $orderCountThisMonth = $this->getOrderCountByMonth($month);
            $monthlySales = []; // Track penjualan bulan ini per produk
            
            for ($i = 0; $i < $orderCountThisMonth; $i++) {
                $day = rand(1, $daysInMonth);
                $orderDate = Carbon::create($year, $month, $day);
                
                $customer = $customers->random();
                
                $numItems = rand(1, 4);
                $selectedProducts = $products->random($numItems);
                
                $subtotal = 0;
                $items = [];
                
                foreach ($selectedProducts as $product) {
                    // Cek stok sebelum menjual
                    $availableStock = $product->stock;
                    $maxQuantity = min(8, $availableStock);
                    
                    if ($maxQuantity <= 0) {
                        continue; // skip produk yang habis
                    }
                    
                    $quantity = rand(1, $maxQuantity);
                    $sellingPrice = $product->selling_price;
                    $costPrice = $product->purchase_price;
                    $itemSubtotal = $sellingPrice * $quantity;
                    $subtotal += $itemSubtotal;
                    
                    $items[] = [
                        'product_id' => $product->id,
                        'quantity' => $quantity,
                        'selling_price' => $sellingPrice,
                        'cost_price' => $costPrice,
                        'discount' => 0,
                        'subtotal' => $itemSubtotal,
                    ];
                    
                    // Kurangi stok
                    $product->decrement('stock', $quantity);
                    
                    // Track penjualan
                    if (!isset($monthlySales[$product->id])) {
                        $monthlySales[$product->id] = 0;
                    }
                    $monthlySales[$product->id] += $quantity;
                    
                    if (!isset($productSales[$product->id])) {
                        $productSales[$product->id] = 0;
                    }
                    $productSales[$product->id] += $quantity;
                }
                
                if (empty($items)) {
                    continue; // skip jika tidak ada item yang bisa dijual
                }
                
                $discount = $subtotal * (rand(0, 5) / 100);
                $totalAmount = $subtotal - $discount;
                
                $paymentRand = rand(1, 100);
                if ($paymentRand <= 70) {
                    $paymentStatus = 'paid';
                    $totalPaid = $totalAmount;
                    $remainingReceivable = 0;
                    $paymentMethod = 'cash';
                } elseif ($paymentRand <= 90) {
                    $paymentStatus = 'unpaid';
                    $totalPaid = 0;
                    $remainingReceivable = $totalAmount;
                    $paymentMethod = 'credit';
                } else {
                    $paymentStatus = 'partial';
                    $totalPaid = $totalAmount * rand(30, 70) / 100;
                    $remainingReceivable = $totalAmount - $totalPaid;
                    $paymentMethod = 'cash';
                }
                
                $order = Order::create([
                    'invoice_number' => 'INV/' . $orderDate->format('Ymd') . '/' . str_pad(($i + 1), 4, '0', STR_PAD_LEFT),
                    'customer_id' => $customer->id,
                    'user_id' => 1,
                    'date' => $orderDate,
                    'source' => 'pos',
                    'subtotal' => $subtotal,
                    'discount' => $discount,
                    'total_amount' => $totalAmount,
                    'total_paid' => $totalPaid,
                    'remaining_receivable' => $remainingReceivable,
                    'payment_status' => $paymentStatus,
                    'payment_method' => $paymentMethod,
                    'notes' => 'Penjualan ' . $orderDate->format('d F Y'),
                ]);
                
                foreach ($items as $item) {
                    OrderItem::create([
                        'order_id' => $order->id,
                        'product_id' => $item['product_id'],
                        'quantity' => $item['quantity'],
                        'selling_price' => $item['selling_price'],
                        'cost_price' => $item['cost_price'],
                        'discount' => $item['discount'],
                        'subtotal' => $item['subtotal'],
                    ]);
                }
                
                $orderCount++;
            }
            
            $this->command->info('      ✅ Orders: ' . $orderCountThisMonth);
            
            // ========== 2. PURCHASES (Pembelian Stok) ==========
            $purchaseCountThisMonth = 0;
            
            // Cek produk yang stoknya di bawah min_stock
            $productsToRestock = Product::where('stock', '<', DB::raw('min_stock * 2'))
                ->get();
            
            // Juga beli untuk produk yang laku keras bulan ini (persiapan bulan depan)
            $topSellingProducts = array_keys(array_slice($monthlySales, 0, 10, true));
            
            $productsToBuy = collect();
            
            foreach ($productsToRestock as $product) {
                $productsToBuy->push($product);
            }
            
            foreach ($topSellingProducts as $productId) {
                $product = Product::find($productId);
                if ($product && !$productsToBuy->contains('id', $productId)) {
                    $productsToBuy->push($product);
                }
            }
            
            $productsToBuy = $productsToBuy->unique('id')->take(rand(5, 12));
            
            if ($productsToBuy->count() > 0) {
                $purchaseCountThisMonth = rand(1, min(6, $productsToBuy->count()));
                $selectedProductsToBuy = $productsToBuy->random($purchaseCountThisMonth);
                
                foreach ($selectedProductsToBuy as $product) {
                    $day = rand(5, 25);
                    $purchaseDate = Carbon::create($year, $month, $day);
                    
                    $supplier = $suppliers->random();
                    
                    $currentStock = $product->stock;
                    $minStock = $product->min_stock;
                    $targetStock = $minStock * 8;
                    $needToBuy = max(20, $targetStock - $currentStock);
                    
                    // Sesuaikan dengan musim
                    if ($month == 5 || $month == 6 || $month == 11 || $month == 12) {
                        $needToBuy = $needToBuy * 1.5;
                    }
                    
                    $quantity = rand(10, min(80, $needToBuy));
                    $purchasePrice = $product->purchase_price;
                    $itemSubtotal = $purchasePrice * $quantity;
                    
                    $paymentRand = rand(1, 100);
                    if ($paymentRand <= 60) {
                        $paymentStatus = 'paid';
                        $totalPaid = $itemSubtotal;
                        $remainingDebt = 0;
                        $paymentMethod = 'cash';
                    } else {
                        $paymentStatus = 'unpaid';
                        $totalPaid = 0;
                        $remainingDebt = $itemSubtotal;
                        $paymentMethod = 'credit';
                    }
                    
                    $purchase = Purchase::create([
                        'reference_number' => 'PO/' . $purchaseDate->format('Ymd') . '/' . str_pad(($purchaseCount + 1), 4, '0', STR_PAD_LEFT),
                        'supplier_id' => $supplier->id,
                        'date' => $purchaseDate,
                        'total_amount' => $itemSubtotal,
                        'total_paid' => $totalPaid,
                        'remaining_debt' => $remainingDebt,
                        'payment_status' => $paymentStatus,
                        'payment_method' => $paymentMethod,
                        'notes' => 'Restock ' . $product->name,
                    ]);
                    
                    PurchaseItem::create([
                        'purchase_id' => $purchase->id,
                        'product_id' => $product->id,
                        'quantity' => $quantity,
                        'purchase_price' => $purchasePrice,
                        'subtotal' => $itemSubtotal,
                    ]);
                    
                    $product->increment('stock', $quantity);
                    $purchaseCount++;
                }
            }
            
            $this->command->info('      ✅ Purchases: ' . $purchaseCountThisMonth);
            
            // ========== 3. EXPENSES (Pengeluaran Operasional) ==========
            $expenseCountThisMonth = rand(5, 12);
            
            for ($i = 0; $i < $expenseCountThisMonth; $i++) {
                $day = rand(1, $daysInMonth);
                $expenseDate = Carbon::create($year, $month, $day);
                
                $category = $existingExpenseCategories[array_rand($existingExpenseCategories)];
                $amount = $this->getExpenseAmountByCategory($category, $month);
                
                if (stripos($category, 'gaji') !== false) {
                    $day = rand(25, $daysInMonth);
                    $expenseDate = Carbon::create($year, $month, $day);
                    $amount = rand(3500000, 5500000);
                }
                
                if (stripos($category, 'sewa') !== false) {
                    $day = 1;
                    $expenseDate = Carbon::create($year, $month, $day);
                }
                
                Expense::create([
                    'user_id' => 1,
                    'category' => $category,
                    'description' => 'Biaya ' . strtolower($category) . ' bulan ' . $expenseDate->translatedFormat('F Y'),
                    'amount' => $amount,
                    'date' => $expenseDate,
                    'reference' => null,
                    'notes' => null,
                ]);
                
                $expenseCount++;
            }
            
            $this->command->info('      ✅ Expenses: ' . $expenseCountThisMonth);
            $this->command->info('');
            
            $currentDate->addMonth();
        }
        
        $this->command->info('');
        $this->command->info('✅ ========== SEEDING COMPLETE ==========');
        $this->command->info('📊 Orders created      : ' . $orderCount);
        $this->command->info('📦 Purchases created   : ' . $purchaseCount);
        $this->command->info('💸 Expenses created    : ' . $expenseCount);
        
        $totalIncome = Order::sum('total_amount');
        $totalExpense = Purchase::sum('total_amount') + Expense::sum('amount');
        
        $this->command->info('');
        $this->command->info('💰 Total Income   : Rp ' . number_format($totalIncome, 0, ',', '.'));
        $this->command->info('💰 Total Expense  : Rp ' . number_format($totalExpense, 0, ',', '.'));
        $this->command->info('📈 Net Profit     : Rp ' . number_format($totalIncome - $totalExpense, 0, ',', '.'));
        
        // Tampilkan stok akhir
        $this->command->info('');
        $this->command->info('📦 Final Stock Summary:');
        $lowStockProducts = Product::where('stock', '<', DB::raw('min_stock'))->get();
        if ($lowStockProducts->count() > 0) {
            $this->command->warn('   ⚠️ Low stock products: ' . $lowStockProducts->count());
            foreach ($lowStockProducts->take(5) as $product) {
                $this->command->line('      - ' . $product->name . ': stock ' . $product->stock . ' (min ' . $product->min_stock . ')');
            }
        } else {
            $this->command->info('   ✅ All products have sufficient stock');
        }
    }
    
    private function getOrderCountByMonth($month)
    {
        // Musim ramai
        if ($month == 5 || $month == 6 || $month == 12) {
            return rand(45, 80);
        }
        // Musim sepi
        if ($month == 1 || $month == 2) {
            return rand(12, 25);
        }
        // Normal
        return rand(20, 45);
    }
    
    private function getExpenseAmountByCategory($category, $month)
    {
        $categoryLower = strtolower($category);
        
        if (strpos($categoryLower, 'listrik') !== false) return rand(350000, 550000);
        if (strpos($categoryLower, 'air') !== false) return rand(180000, 280000);
        if (strpos($categoryLower, 'internet') !== false) return rand(350000, 450000);
        if (strpos($categoryLower, 'gaji') !== false) return rand(4000000, 6000000);
        if (strpos($categoryLower, 'transport') !== false) return rand(600000, 1200000);
        if (strpos($categoryLower, 'maintenance') !== false) return rand(250000, 600000);
        if (strpos($categoryLower, 'atk') !== false) return rand(120000, 350000);
        if (strpos($categoryLower, 'kebersihan') !== false) return rand(80000, 180000);
        if (strpos($categoryLower, 'marketing') !== false) return rand(250000, 600000);
        if (strpos($categoryLower, 'sewa') !== false) return rand(3000000, 4000000);
        
        return rand(150000, 500000);
    }
}