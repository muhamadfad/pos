<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('kaspro_alerts', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained();
            $table->string('type'); // low_cash, high_expense, anomaly, cash_flow_gap
            $table->string('severity'); // info, warning, critical, emergency
            $table->string('title');
            $table->text('message');
            $table->json('data')->nullable();
            $table->string('source_type')->nullable(); // purchase, order, expense
            $table->unsignedBigInteger('source_id')->nullable();
            $table->boolean('is_read')->default(false);
            $table->boolean('is_resolved')->default(false);
            $table->timestamp('resolved_at')->nullable();
            $table->timestamps();
            
            $table->index(['user_id', 'is_read']);
            $table->index(['user_id', 'severity']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('kaspro_alerts');
    }
};