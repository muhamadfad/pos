<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('kaspro_predictions', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained();
            $table->string('month');
            $table->decimal('predicted_income', 15, 2);
            $table->decimal('predicted_expense', 15, 2);
            $table->decimal('predicted_net', 15, 2);
            $table->json('details')->nullable();
            $table->timestamps();
            
            $table->unique(['user_id', 'month']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('kaspro_predictions');
    }
};