<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('expenses', function (Blueprint $table) {
            $table->string('kaspro_category')->nullable();
            $table->integer('kaspro_confidence')->nullable();
            $table->boolean('kaspro_needs_review')->default(false);
            $table->boolean('kaspro_is_anomaly')->default(false);
            $table->integer('kaspro_risk_score')->default(0);
            $table->json('kaspro_anomaly_flags')->nullable();
        });
    }

    public function down(): void
    {
        Schema::table('expenses', function (Blueprint $table) {
            $table->dropColumn([
                'kaspro_category', 'kaspro_confidence', 'kaspro_needs_review',
                'kaspro_is_anomaly', 'kaspro_risk_score', 'kaspro_anomaly_flags'
            ]);
        });
    }
};